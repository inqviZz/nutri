import test from 'node:test';
import assert from 'node:assert/strict';
import { parseText, matchFood } from '../src/core/parser';
import { SEED_FOODS, searchFoodsLocal } from '../src/core/foods';
import { normalizeOff } from '../src/core/off';
import { targets, macroFor, addDays, guessMeal } from '../src/core/nutrition';

test('парсер: граммы, штуки, составные названия, точность', () => {
  const rows = parseText('овсянка с бананом и кофе с молоком, 2 яйца, 200 г гречки, грудка, пицца 2 куска', SEED_FOODS);
  const by = (n: string) => rows.find(r => r.food!.name.startsWith(n))!;
  assert.equal(by('Овсяная').grams, 250); assert.equal(by('Овсяная').precision, 'guess');
  assert.ok(by('Банан')); assert.ok(by('Кофе с молоком'));
  assert.equal(by('Яйцо').grams, 110); assert.equal(by('Яйцо').precision, 'standard');
  assert.equal(by('Гречка').grams, 200); assert.equal(by('Гречка').precision, 'exact');
  assert.equal(by('Пицца').grams, 220);
  assert.ok(by('Куриная грудка'));
});
test('парсер: «500 г гречки» не превращается в «порцию»', () => {
  const [r] = parseText('гречка 500 г', SEED_FOODS); assert.equal(r.grams, 500); assert.equal(r.precision, 'exact');
});
test('match и поиск по морфологии', () => {
  assert.equal(matchFood('куриную грудку', SEED_FOODS)?.name, 'Куриная грудка варёная');
  assert.ok(searchFoodsLocal('гречку', SEED_FOODS).some(f => f.name === 'Гречка отварная'));
  assert.ok(searchFoodsLocal('творог', SEED_FOODS).length >= 2);
});
test('OFF: отсекает ошибочные данные', () => {
  assert.equal(normalizeOff({ code: '1', product_name: 'X', nutriments: { 'energy-kcal_100g': 500, proteins_100g: 1, fat_100g: 1, carbohydrates_100g: 1 } }), null);
  assert.equal(normalizeOff({ code: '2', product_name: 'Кефир', nutriments: { 'energy-kj_100g': 222, proteins_100g: 3, fat_100g: 2.5, carbohydrates_100g: 4 } })!.kcal, 53);
});
test('нормы и даты', () => {
  const T = targets({ name: '', sex: 'm', age: 32, height: 180, weight: 82.4, goalWeight: 76, activity: 1.375, goal: 'lose', updatedAt: 0 });
  assert.ok(T.kcal > 1900 && T.kcal < 2400, String(T.kcal)); assert.equal(T.protein, 157);
  assert.deepEqual(macroFor({ kcal: 110, protein: 4.2, fat: 1.1, carbs: 21.3 }, 200), { kcal: 220, protein: 8.4, fat: 2.2, carbs: 42.6 });
  assert.equal(addDays('2026-09-30', 1), '2026-10-01'); assert.equal(addDays('2026-03-01', -1), '2026-02-28');
  assert.equal(guessMeal('на ужин пицца'), 'd');
});

import { whtr, whtrLabel, navyFat, katchBmr, leanFrom, adaptiveTdee, basisFor, labFlag, sanitizeComp, slope } from '../src/core/body';

test('тело: талия/рост, Кэтч–Макардл, обхваты', () => {
  assert.equal(whtrLabel(whtr(80, 180)!), 'в норме'); assert.equal(whtrLabel(whtr(100, 170)!), 'повышено');
  assert.equal(whtr(0, 180), null);
  assert.equal(Math.round(katchBmr(leanFrom(80, 20))), 1752);
  const f = navyFat('m', 180, 90, 38)!; assert.ok(f > 15 && f < 25, String(f));
  assert.equal(navyFat('f', 165, 70, 32), null); // для женщин нужны бёдра
  assert.ok(Math.abs(slope([{ x: 0, y: 80 }, { x: 10, y: 79 }]) + 0.1) < 1e-9);
});

test('адаптивный расход: 2000 ккал и −0,1 кг/день → ≈2770', () => {
  const now = '2026-10-05'; const entries: any = {}; const weights: any = {};
  for (let i = 0; i < 28; i++) { const d = addDays(now, -i); entries['e' + i] = { id: 'e' + i, date: d, kcal: 2000, protein: 0, fat: 0, carbs: 0, updatedAt: 1 }; if (i % 3 === 0) weights[d] = { kg: 80 - 0.1 * (27 - i) }; }
  const a = adaptiveTdee(entries, weights, now)!;
  assert.ok(a && Math.abs(a.tdee - 2770) < 60, JSON.stringify(a));
  assert.equal(adaptiveTdee({}, weights, now), null); // мало записей дневника
  const p: any = { sex: 'm', age: 30, height: 180, weight: 80, goalWeight: 75, activity: 1.4, goal: 'lose' };
  assert.equal(basisFor(p, entries, weights, {}, 'auto', now).mode, 'adaptive');
  assert.equal(basisFor(p, {}, {}, {}, 'auto', now).mode, 'mifflin');
  assert.equal(basisFor(p, {}, {}, { c: { id: 'c', date: '2026-09-20', fatPct: 20 } as any }, 'auto', now).mode, 'katch');
});

test('норма: нижняя граница калорий и несовершеннолетние', () => {
  const small: any = { sex: 'f', age: 40, height: 155, weight: 50, goalWeight: 48, activity: 1.2, goal: 'lose' };
  const T = targets(small); assert.equal(T.kcal, 1200); assert.equal(T.limited, true);
  const kid = targets({ ...small, age: 16, goal: 'lose' }); assert.equal(kid.minor, true); assert.ok(kid.kcal >= kid.tdee - 10);
});

test('анализы и распознавание: флаги и отбраковка невозможных чисел', () => {
  assert.equal(labFlag({ value: 5, refLow: 3, refHigh: 6 }), 'ok'); assert.equal(labFlag({ value: 7, refLow: 3, refHigh: 6 }), 'high');
  assert.equal(labFlag({ value: 2, refLow: 3, refHigh: 6 }), 'low'); assert.equal(labFlag({ value: 2 }), 'none');
  const c = sanitizeComp({ weightKg: 82.04, fatPct: 250, muscleKg: 3 }); assert.equal(c.weightKg, 82); assert.equal(c.fatPct, undefined); assert.equal(c.muscleKg, undefined);
});

test('база продуктов: нет дублей, КБЖУ сходится с калорийностью', () => {
  const names = new Set(SEED_FOODS.map(f => f.name.toLowerCase())); assert.equal(names.size, SEED_FOODS.length);
  assert.equal(new Set(SEED_FOODS.map(f => f.id)).size, SEED_FOODS.length);
  assert.ok(SEED_FOODS.length >= 300);
  for (const f of SEED_FOODS) { assert.ok(f.protein + f.fat + f.carbs <= 100.5, f.name); }
});
