import { useStore } from './store';
import { logEvent } from './diag';

export interface LlmPreset { id: string; label: string; url: string; model: string; hint: string }
/** Адреса и модели взяты из документации провайдеров; названия моделей могут меняться — их можно править в приложении. */
export const LLM_PRESETS: LlmPreset[] = [
  { id: 'deepseek', label: 'DeepSeek', url: 'https://api.deepseek.com/chat/completions', model: 'deepseek-flash', hint: 'Регистрация по e-mail, ключ на platform.deepseek.com → API keys. При регистрации дают стартовые бесплатные токены (условия могут меняться).' },
  { id: 'routerai', label: 'RouterAI (Claude, GPT…)', url: 'https://routerai.ru/api/v1/chat/completions', model: 'anthropic/claude-sonnet-4.6', hint: 'Российский агрегатор: оплата картой РФ/СБП, один ключ для разных моделей, в том числе Claude. Название модели смотрите в их каталоге.' },
  { id: 'custom', label: 'Другой (OpenAI-совместимый)', url: '', model: '', hint: 'Любой сервис с OpenAI-совместимым API: укажите адрес .../chat/completions, ключ и модель.' },
];

export const llmConfigured = () => { const s = useStore.getState().settings; return !!(s.llmKey && s.llmUrl && s.llmModel); };

export async function callLlm(messages: { role: string; content: any }[], temperature = 0.3, timeoutMs = 30000): Promise<string> {
  const s = useStore.getState().settings;
  if (!llmConfigured()) throw new Error('llm_not_configured');
  const ctrl = new AbortController(); const to = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(s.llmUrl!, { method: 'POST', signal: ctrl.signal, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + s.llmKey }, body: JSON.stringify({ model: s.llmModel, temperature, messages }) });
    const j: any = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(`LLM HTTP ${r.status}: ${j?.error?.message ?? j?.message ?? ''}`.trim());
    const text = j.choices?.[0]?.message?.content;
    if (typeof text !== 'string') throw new Error('LLM: пустой ответ');
    return text.trim();
  } catch (e: any) { logEvent('llm', e?.name === 'AbortError' ? 'таймаут' : e); throw e; }
  finally { clearTimeout(to); }
}

const PARSE_SYSTEM = `Ты помощник нутрициолога. Из текста пользователя выдели съеденные продукты.
Верни ТОЛЬКО JSON-массив: [{"name":"простое название продукта","grams":число,"assumed":true|false,"confidence":0..1}].
- name: как продукт называют в магазине/справочнике («гречка отварная», «яйцо варёное»).
- grams: если пользователь назвал вес — используй его, assumed=false. Если нет — оцени типичную порцию и поставь assumed=true.
- НЕ указывай калории и БЖУ.`;

export async function llmParse(text: string) {
  const raw = await callLlm([{ role: 'system', content: PARSE_SYSTEM }, { role: 'user', content: text }], 0.1);
  const m = raw.match(/\[[\s\S]*\]/); if (!m) throw new Error('LLM: нет JSON');
  const arr = JSON.parse(m[0]) as any[];
  return arr.filter(x => x && typeof x.name === 'string' && Number(x.grams) > 0 && Number(x.grams) < 5000)
    .map(x => ({ name: String(x.name), grams: Number(x.grams), assumed: !!x.assumed, confidence: Number(x.confidence) || 0.5 }));
}

/** Системная инструкция AI-тренера. Данные пользователя подставляются из дневника. */
export const COACH_SYSTEM = `Ты — персональный тренер-нутрициолог в приложении-дневнике питания. Говоришь по-русски, тепло, уважительно, без нравоучений и без запугивания.

Принципы:
1. Опирайся ТОЛЬКО на данные пользователя ниже. Если данных не хватает — задай один короткий уточняющий вопрос. Никогда не выдумывай калории, БЖУ и факты о пользователе.
2. Отвечай коротко: 3–6 предложений или короткий список. Всегда заканчивай одним конкретным следующим шагом («сегодня на ужин…», «выпейте стакан воды»).
3. Предлагай реалистичные варианты из обычных продуктов с примерными граммами и калориями, подгоняя под остаток калорий и белка на сегодня.
4. Срыв или перебор — норма жизни. Поддержи, не ругай, предложи спокойный план на завтра, без голодания и «отработки».
5. Не ставь диагнозов и не назначай лечение. Если пользователь пишет о болезнях, беременности, расстройствах питания, очень низких калориях (< 1200 ккал у женщин, < 1500 у мужчин) или резкой потере веса — мягко посоветуй обратиться к врачу/диетологу.
6. Темп похудения 0,3–0,7 кг в неделю считай безопасным; быстрее — не рекомендуй.
7. Если данные из Samsung Health есть (шаги, активные ккал), учитывай их, но помни, что часы завышают расход.`;
