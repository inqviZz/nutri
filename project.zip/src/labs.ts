import * as ImagePicker from 'expo-image-picker';
import { manipulateAsync, SaveFormat } from 'expo-image-manipulator';
import { callLlm } from './llm';
import { sanitizeComp } from './core/body';
import type { BodyComp } from './core/types';
import { today } from './core/nutrition';
import { logEvent } from './diag';

/** Снять или выбрать фото документа, уменьшить до ~1600 px и вернуть JPEG в base64. */
export async function pickDocPhoto(source: 'camera' | 'library'): Promise<{ uri: string; b64: string } | null> {
  try {
    const opts: ImagePicker.ImagePickerOptions = { mediaTypes: ['images'], quality: 0.8 };
    let res: ImagePicker.ImagePickerResult;
    if (source === 'camera') {
      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (!perm.granted) throw new Error('Нет доступа к камере (Настройки → Приложения → Nutri → Разрешения)');
      res = await ImagePicker.launchCameraAsync(opts);
    } else res = await ImagePicker.launchImageLibraryAsync(opts);
    if (res.canceled || !res.assets?.[0]) return null;
    const a = res.assets[0];
    const small = await manipulateAsync(a.uri, [{ resize: a.width >= a.height ? { width: 1600 } : { height: 1600 } }], { compress: 0.75, format: SaveFormat.JPEG, base64: true });
    if (!small.base64) throw new Error('Не удалось подготовить фото');
    return { uri: small.uri, b64: small.base64 };
  } catch (e) { logEvent('pick-photo', e); throw e; }
}

export interface LabRow { name: string; value: number; unit: string; refLow: number | null; refHigh: number | null }
export interface DocResult { kind: 'composition' | 'labs' | 'both' | 'unknown'; date: string; comp: Partial<BodyComp>; labs: LabRow[] }

const SYSTEM = `Ты извлекаешь данные из фотографии медицинского бланка или распечатки анализатора состава тела (БИА: InBody, Tanita, умные весы, часы).
Верни ТОЛЬКО JSON без пояснений такого вида:
{"kind":"composition|labs|both|unknown","date":"YYYY-MM-DD или null",
"composition":{"weightKg":число|null,"fatPct":число|null,"muscleKg":число|null,"leanKg":число|null,"waterPct":число|null,"visceral":число|null,"boneKg":число|null,"bmr":число|null},
"labs":[{"name":"название показателя по-русски","value":число,"unit":"единицы как в бланке","refLow":число|null,"refHigh":число|null}]}
Правила:
- Переписывай ТОЛЬКО то, что ясно видно. Если значение нечитаемо или его нет — null. НИЧЕГО не угадывай и не вычисляй.
- Десятичная запятая → точка. Единицы не пересчитывай, для composition килограммы и проценты как на бланке.
- muscleKg — масса скелетных мышц (или мышечная масса), leanKg — безжировая масса, fatPct — процент жира, bmr — основной обмен в ккал.
- В labs включай анализы крови/мочи и т.п. с референсными значениями из бланка (refLow/refHigh, если указан диапазон; для «до N» refLow = null).
- Не добавляй ФИО, даты рождения и другие персональные данные.
- Если на фото нет ни состава тела, ни анализов — kind "unknown".`;

const num = (v: any) => { const n = typeof v === 'string' ? Number(v.replace(',', '.')) : Number(v); return v == null || v === '' || !Number.isFinite(n) ? null : n; };

/** Отправляет фото в AI-модель с поддержкой изображений и возвращает проверенный на правдоподобие результат. Значения ВСЕГДА нужно показать пользователю на подтверждение. */
export async function recognizeDocument(b64: string): Promise<DocResult> {
  const raw = await callLlm([
    { role: 'system', content: SYSTEM },
    { role: 'user', content: [{ type: 'text', text: 'Извлеки данные с этого документа.' }, { type: 'image_url', image_url: { url: 'data:image/jpeg;base64,' + b64 } }] },
  ], 0, 90000);
  const m = raw.match(/\{[\s\S]*\}/); if (!m) throw new Error('Модель не вернула данные. Возможно, она не умеет читать картинки — выберите модель с поддержкой изображений (например, Claude через RouterAI).');
  let j: any; try { j = JSON.parse(m[0]); } catch { throw new Error('Не удалось разобрать ответ модели'); }
  const comp = sanitizeComp({ weightKg: num(j.composition?.weightKg) ?? undefined, fatPct: num(j.composition?.fatPct) ?? undefined, muscleKg: num(j.composition?.muscleKg) ?? undefined, leanKg: num(j.composition?.leanKg) ?? undefined, waterPct: num(j.composition?.waterPct) ?? undefined, visceral: num(j.composition?.visceral) ?? undefined, boneKg: num(j.composition?.boneKg) ?? undefined, bmr: num(j.composition?.bmr) ?? undefined });
  const labs: LabRow[] = (Array.isArray(j.labs) ? j.labs : []).map((x: any) => ({ name: String(x?.name ?? '').slice(0, 80), value: num(x?.value), unit: String(x?.unit ?? '').slice(0, 20), refLow: num(x?.refLow), refHigh: num(x?.refHigh) }))
    .filter((x: any) => x.name && x.value != null).slice(0, 60);
  const date = typeof j.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(j.date) && j.date <= today() ? j.date : today();
  const hasC = Object.keys(comp).length > 0, hasL = labs.length > 0;
  return { kind: hasC && hasL ? 'both' : hasC ? 'composition' : hasL ? 'labs' : 'unknown', date, comp, labs };
}
