import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { BodyComp, Entry, Food, LabItem, MealId, Measure, Profile, Settings } from './core/types';
import { addDays, macroFor, today, uid } from './core/nutrition';

export interface Change { id: string; kind: 'entry' | 'water' | 'weight' | 'profile' | 'food' | 'settings' | 'measure' | 'bodycomp'; data: unknown; updatedAt: number; deleted?: boolean }
type Weight = { kg: number; updatedAt: number; source?: 'manual' | 'health' };
type Water = { ml: number; updatedAt: number };
export interface HealthDay { steps: number; activeKcal: number }

interface State {
  profile: Profile;
  settings: Settings;
  entries: Record<string, Entry>;
  water: Record<string, Water>;
  weights: Record<string, Weight>;
  measures: Record<string, Measure>;
  bodycomp: Record<string, BodyComp>;
  labs: Record<string, LabItem>;       // только локально
  customFoods: Record<string, Food>;
  foodCache: Record<string, Food>;      // продукты, найденные через сервер / штрихкод
  health: Record<string, HealthDay>;    // только локально, на сервер не отправляется
  healthSyncedAt: number | null;
  token: string | null;
  email: string | null;
  cursor: number;
  outbox: Record<string, Change>;
  welcomed: boolean;

  addEntry(p: { date: string; meal: MealId; food: Food; grams: number }): Entry;
  updateEntry(id: string, grams: number, food?: Food): void;
  removeEntry(id: string): void;
  addWater(date: string, delta: number): void;
  setWeight(date: string, kg: number, source?: 'manual' | 'health'): void;
  saveMeasure(date: string, patch: Partial<Omit<Measure, 'updatedAt'>>): void;
  removeMeasure(date: string): void;
  addBodyComp(c: Omit<BodyComp, 'id' | 'updatedAt'> & { id?: string }): void;
  removeBodyComp(id: string): void;
  addLabs(items: Omit<LabItem, 'id' | 'updatedAt'>[]): void;
  removeLab(id: string): void;
  saveProfile(p: Partial<Profile>): void;
  setSettings(s: Partial<Settings>): void;
  saveCustomFood(f: Food): void;
  cacheFoods(fs: Food[]): void;
  setHealth(h: Record<string, HealthDay>): void;
  setAuth(token: string | null, email: string | null): void;
  applyRemote(changes: Change[], cursor: number): void;
  clearOutbox(ids: string[]): void;
  setWelcomed(): void;
  resetAll(): void;
}

const defaults = () => ({
  profile: { name: 'Друг', sex: 'm', age: 30, height: 175, weight: 75, goalWeight: 70, activity: 1.375, goal: 'lose', updatedAt: 0 } as Profile,
  settings: { theme: 'system', social: false, serverUrl: '', eatBack: 0, hcEnabled: false, hcWriteWeight: false, hcWriteNutrition: false, llmPreset: '', llmUrl: '', llmKey: '', llmModel: '', normMode: 'auto', visionConsent: false } as Settings,
  entries: {}, water: {}, weights: {}, measures: {}, bodycomp: {}, labs: {}, customFoods: {}, foodCache: {}, health: {}, healthSyncedAt: null,
  token: null, email: null, cursor: 0, outbox: {}, welcomed: false,
});

export const useStore = create<State>()(persist((set, get) => {
  const queue = (c: Change) => ({ outbox: { ...get().outbox, [c.id]: c } });
  return {
    ...defaults(),

    addEntry({ date, meal, food, grams }) {
      const e: Entry = { id: uid(), date, meal, name: food.name, grams, ...macroFor(food, grams), foodId: food.id, updatedAt: Date.now() };
      set(s => ({ entries: { ...s.entries, [e.id]: e }, ...queue({ id: e.id, kind: 'entry', data: e, updatedAt: e.updatedAt }) }));
      return e;
    },
    updateEntry(id, grams, food) {
      const old = get().entries[id]; if (!old) return;
      const per = food ?? { kcal: old.kcal / old.grams * 100, protein: old.protein / old.grams * 100, fat: old.fat / old.grams * 100, carbs: old.carbs / old.grams * 100 };
      const e: Entry = { ...old, grams, ...macroFor(per, grams), updatedAt: Date.now() };
      set(s => ({ entries: { ...s.entries, [id]: e }, ...queue({ id, kind: 'entry', data: e, updatedAt: e.updatedAt }) }));
    },
    removeEntry(id) {
      const old = get().entries[id]; if (!old) return;
      const now = Date.now();
      set(s => { const { [id]: _, ...rest } = s.entries; return { entries: rest, ...queue({ id, kind: 'entry', data: null, updatedAt: now, deleted: true }) }; });
    },
    addWater(date, delta) {
      const ml = Math.max(0, (get().water[date]?.ml ?? 0) + delta), now = Date.now();
      set(s => ({ water: { ...s.water, [date]: { ml, updatedAt: now } }, ...queue({ id: 'water:' + date, kind: 'water', data: { date, ml }, updatedAt: now }) }));
    },
    setWeight(date, kg, source = 'manual') {
      const now = Date.now();
      set(s => ({
        weights: { ...s.weights, [date]: { kg, updatedAt: now, source } },
        profile: date === today() ? { ...s.profile, weight: kg, updatedAt: now } : s.profile,
        ...queue({ id: 'weight:' + date, kind: 'weight', data: { date, kg, source }, updatedAt: now }),
      }));
    },
    saveMeasure(date, patch) {
      const now = Date.now(); const m: Measure = { ...(get().measures[date] ?? {}), ...patch, updatedAt: now };
      set(s => ({ measures: { ...s.measures, [date]: m }, ...queue({ id: 'measure:' + date, kind: 'measure', data: { date, ...m }, updatedAt: now }) }));
    },
    removeMeasure(date) {
      const now = Date.now();
      set(s => { const { [date]: _, ...rest } = s.measures; return { measures: rest, ...queue({ id: 'measure:' + date, kind: 'measure', data: null, updatedAt: now, deleted: true }) }; });
    },
    addBodyComp(c) {
      const now = Date.now(); const id = c.id ?? uid(); const full: BodyComp = { ...c, id, updatedAt: now };
      set(s => ({ bodycomp: { ...s.bodycomp, [id]: full }, ...queue({ id: 'bodycomp:' + id, kind: 'bodycomp', data: full, updatedAt: now }) }));
    },
    removeBodyComp(id) {
      const now = Date.now();
      set(s => { const { [id]: _, ...rest } = s.bodycomp; return { bodycomp: rest, ...queue({ id: 'bodycomp:' + id, kind: 'bodycomp', data: null, updatedAt: now, deleted: true }) }; });
    },
    addLabs(items) {
      const now = Date.now();
      set(s => { const labs = { ...s.labs }; items.forEach((it, i) => { const id = uid() + i; labs[id] = { ...it, id, updatedAt: now }; }); return { labs }; });
    },
    removeLab(id) { set(s => { const { [id]: _, ...rest } = s.labs; return { labs: rest }; }); },
    saveProfile(p) {
      const profile = { ...get().profile, ...p, updatedAt: Date.now() };
      set(s => ({ profile, ...queue({ id: 'profile', kind: 'profile', data: profile, updatedAt: profile.updatedAt }) }));
    },
    setSettings(s) { set(st => ({ settings: { ...st.settings, ...s } })); },
    saveCustomFood(f) {
      const now = Date.now();
      set(s => ({ customFoods: { ...s.customFoods, [f.id]: f }, ...queue({ id: 'food:' + f.id, kind: 'food', data: f, updatedAt: now }) }));
    },
    cacheFoods(fs) {
      set(s => {
        const c = { ...s.foodCache }; fs.forEach(f => { c[f.id] = f; });
        const keys = Object.keys(c); if (keys.length > 500) keys.slice(0, keys.length - 500).forEach(k => delete c[k]);
        return { foodCache: c };
      });
    },
    setHealth(h) { set(s => ({ health: { ...s.health, ...h }, healthSyncedAt: Date.now() })); },
    setAuth(token, email) { set({ token, email, ...(token ? {} : { cursor: 0 }) }); },

    // --- применение изменений с сервера: побеждает более новый updatedAt ---
    applyRemote(changes, cursor) {
      set(s => {
        const entries = { ...s.entries }, water = { ...s.water }, weights = { ...s.weights }, customFoods = { ...s.customFoods }, measures = { ...s.measures }, bodycomp = { ...s.bodycomp };
        let profile = s.profile;
        for (const c of changes) {
          const ownPending = s.outbox[c.id];
          if (ownPending && ownPending.updatedAt > c.updatedAt) continue;
          if (c.kind === 'entry') { if (c.deleted) delete entries[c.id]; else if (!entries[c.id] || entries[c.id].updatedAt <= c.updatedAt) entries[c.id] = c.data as Entry; }
          else if (c.kind === 'water') { const d = c.data as any; if (!water[d.date] || water[d.date].updatedAt <= c.updatedAt) water[d.date] = { ml: d.ml, updatedAt: c.updatedAt }; }
          else if (c.kind === 'weight') { const d = c.data as any; if (!weights[d.date] || weights[d.date].updatedAt <= c.updatedAt) weights[d.date] = { kg: d.kg, updatedAt: c.updatedAt, source: d.source }; }
          else if (c.kind === 'measure') { const d = c.data as any; const date = c.id.replace('measure:', ''); if (c.deleted) delete measures[date]; else if (d && (!measures[date] || measures[date].updatedAt <= c.updatedAt)) { const { date: _d, ...m } = d; measures[date] = { ...m, updatedAt: c.updatedAt }; } }
          else if (c.kind === 'bodycomp') { const d = c.data as BodyComp | null; const id = c.id.replace('bodycomp:', ''); if (c.deleted) delete bodycomp[id]; else if (d && (!bodycomp[id] || bodycomp[id].updatedAt <= c.updatedAt)) bodycomp[id] = d; }
          else if (c.kind === 'profile') { if (profile.updatedAt <= c.updatedAt) profile = c.data as Profile; }
          else if (c.kind === 'food') { if (!c.deleted) customFoods[(c.data as Food).id] = c.data as Food; }
        }
        return { entries, water, weights, customFoods, measures, bodycomp, profile, cursor };
      });
    },
    clearOutbox(ids) {
      set(s => { const o = { ...s.outbox }; ids.forEach(id => { if (o[id]) delete o[id]; }); return { outbox: o }; });
    },
    setWelcomed() { set({ welcomed: true }); },
    resetAll() { set({ ...defaults(), welcomed: true }); },
  };
}, {
  name: 'nutri-store-v1',
  storage: createJSONStorage(() => AsyncStorage),
  version: 1,
}));

// ---------- селекторы ----------
export const entriesOn = (entries: Record<string, Entry>, date: string) =>
  Object.values(entries).filter(e => e.date === date).sort((a, b) => a.updatedAt - b.updatedAt);

export function streak(entries: Record<string, Entry>) {
  const days = new Set(Object.values(entries).map(e => e.date));
  let k = today(), n = 0;
  if (!days.has(k)) k = addDays(k, -1);
  while (days.has(k)) { n++; k = addDays(k, -1); }
  return n;
}

/** Последняя использованная порция продукта — умолчание вместо «средней порции». */
export function lastPortion(entries: Record<string, Entry>, foodId: string): number | null {
  let best: Entry | null = null;
  for (const e of Object.values(entries)) if (e.foodId === foodId && (!best || e.updatedAt > best.updatedAt)) best = e;
  return best ? best.grams : null;
}

/** Норма с учётом состава тела и реальной динамики веса. Использовать вместо targets(profile). */
import { fullTargets } from './core/body';
import { useMemo } from 'react';
export function useTargets() {
  const profile = useStore(s => s.profile), entries = useStore(s => s.entries), weights = useStore(s => s.weights), comps = useStore(s => s.bodycomp), mode = useStore(s => s.settings.normMode ?? 'auto');
  return useMemo(() => fullTargets(profile, entries, weights, comps, mode), [profile, entries, weights, comps, mode]);
}
export const currentTargets = () => { const s = useStore.getState(); return fullTargets(s.profile, s.entries, s.weights, s.bodycomp, s.settings.normMode ?? 'auto'); };
