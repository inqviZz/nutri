import React from 'react';
import { Pressable, Text, TextInput, View, StyleSheet, useColorScheme, type TextInputProps, type ViewStyle } from 'react-native';
import Svg, { Circle, Defs, LinearGradient, Stop } from 'react-native-svg';
import { useStore } from './store';

const light = { bg: '#f4f6fb', card: '#ffffff', text: '#0f172a', muted: '#64748b', line: '#e8ecf4', acc: '#16a34a', acc2: '#14b8a6', accSoft: '#e7f8ee', ai1: '#7c3aed', ai2: '#2563eb', aiSoft: '#f1ebff', p: '#3b82f6', f: '#f59e0b', c: '#ec4899', water: '#0ea5e9', danger: '#ef4444', warn: '#b45309', warnSoft: '#fef3c7' };
const dark: typeof light = { ...light, bg: '#0b1020', card: '#151b2e', text: '#e9edf7', muted: '#8b96b2', line: '#232b45', accSoft: '#10301f', aiSoft: '#231a45', warn: '#fbbf24', warnSoft: '#3a2a08' };
export type Theme = typeof light & { dark: boolean };

export function useTheme(): Theme {
  const sys = useColorScheme(); const pref = useStore(s => s.settings.theme);
  const isDark = pref === 'system' ? sys === 'dark' : pref === 'dark';
  return { ...(isDark ? dark : light), dark: isDark };
}

export function Txt({ children, style, size = 15, bold, muted, color, numberOfLines }: { children?: React.ReactNode; style?: any; size?: number; bold?: boolean; muted?: boolean; color?: string; numberOfLines?: number }) {
  const t = useTheme();
  return <Text numberOfLines={numberOfLines} style={[{ fontSize: size, color: color ?? (muted ? t.muted : t.text), fontWeight: bold ? '700' : '400' }, style]}>{children}</Text>;
}

export function Card({ children, style }: { children?: React.ReactNode; style?: ViewStyle }) {
  const t = useTheme();
  return <View style={[s.card, { backgroundColor: t.card, shadowColor: '#0f172a' }, style]}>{children}</View>;
}

export function Btn({ title, onPress, kind = 'primary', small, disabled, style }: { title: string; onPress?: () => void; kind?: 'primary' | 'ai' | 'ghost' | 'danger'; small?: boolean; disabled?: boolean; style?: ViewStyle }) {
  const t = useTheme();
  const bg = kind === 'primary' ? t.acc : kind === 'ai' ? t.ai1 : 'transparent';
  const fg = kind === 'primary' || kind === 'ai' ? '#fff' : kind === 'danger' ? t.danger : t.text;
  return (
    <Pressable disabled={disabled} onPress={onPress} style={({ pressed }) => [s.btn, small && { paddingVertical: 9, paddingHorizontal: 14, alignSelf: 'flex-start' }, { backgroundColor: bg, borderColor: t.line, borderWidth: bg === 'transparent' ? 1.5 : 0, opacity: disabled ? 0.5 : pressed ? 0.85 : 1 }, style]}>
      <Text style={{ color: fg, fontWeight: '700', fontSize: small ? 13 : 15 }}>{title}</Text>
    </Pressable>
  );
}

export function Chip({ label, on, onPress }: { label: string; on?: boolean; onPress?: () => void }) {
  const t = useTheme();
  return (
    <Pressable onPress={onPress} style={[s.chip, { backgroundColor: on ? t.accSoft : t.bg, borderColor: on ? t.acc : t.line }]}>
      <Text style={{ color: on ? t.acc : t.text, fontWeight: '600', fontSize: 13 }}>{label}</Text>
    </Pressable>
  );
}

export function Input(props: TextInputProps & { label?: string }) {
  const t = useTheme();
  return (
    <View style={{ flex: 1 }}>
      {props.label ? <Txt size={12} muted style={{ marginBottom: 4 }}>{props.label}</Txt> : null}
      <TextInput placeholderTextColor={t.muted} {...props} style={[s.input, { backgroundColor: t.bg, borderColor: t.line, color: t.text }, props.style]} />
    </View>
  );
}

export function Bar({ value, max, color }: { value: number; max: number; color: string }) {
  const t = useTheme();
  return <View style={{ height: 7, borderRadius: 9, backgroundColor: t.line, overflow: 'hidden' }}><View style={{ height: 7, borderRadius: 9, width: `${Math.min(100, (value / Math.max(max, 1)) * 100)}%`, backgroundColor: color }} /></View>;
}

export function Ring({ pct, over, size = 140, children }: { pct: number; over?: boolean; size?: number; children?: React.ReactNode }) {
  const t = useTheme(); const R = size / 2 - 11, C = 2 * Math.PI * R, v = Math.min(Math.max(pct, 0), 1);
  return (
    <View style={{ width: size, height: size }}>
      <Svg width={size} height={size} style={{ transform: [{ rotate: '-90deg' }] }}>
        <Defs><LinearGradient id="rg" x1="0" y1="0" x2="1" y2="1"><Stop offset="0" stopColor={over ? '#f97316' : '#22c55e'} /><Stop offset="1" stopColor={over ? '#ef4444' : '#14b8a6'} /></LinearGradient></Defs>
        <Circle cx={size / 2} cy={size / 2} r={R} stroke={t.line} strokeWidth={13} fill="none" />
        <Circle cx={size / 2} cy={size / 2} r={R} stroke="url(#rg)" strokeWidth={13} fill="none" strokeLinecap="round" strokeDasharray={`${C}`} strokeDashoffset={C * (1 - v)} />
      </Svg>
      <View style={[StyleSheet.absoluteFill, { alignItems: 'center', justifyContent: 'center' }]}>{children}</View>
    </View>
  );
}

export const s = StyleSheet.create({
  card: { borderRadius: 20, padding: 16, marginBottom: 14, shadowOpacity: 0.06, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 2 },
  btn: { borderRadius: 16, paddingVertical: 14, alignItems: 'center', justifyContent: 'center' },
  chip: { paddingHorizontal: 13, paddingVertical: 8, borderRadius: 99, borderWidth: 1.5, marginRight: 8 },
  input: { borderWidth: 1.5, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 11, fontSize: 15 },
  row: { flexDirection: 'row', alignItems: 'center' },
});
