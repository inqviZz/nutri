import React, { useEffect, useMemo, useRef, useState } from 'react';
import { FlatList, Pressable, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Screen } from '../components/Screen';
import { Btn, Input, Txt, s, useTheme } from '../ui';
import { useStore } from '../store';
import { SEED_FOODS, searchFoodsLocal } from '../core/foods';
import type { Food } from '../core/types';
import { searchRemote } from '../api';

export function SourceBadge({ f }: { f: Food }) {
  const t = useTheme();
  const map = { seed: ['✓ справочник', t.acc], off: [f.quality >= 1 ? 'Open Food Facts' : 'OFF · проверьте', f.quality >= 1 ? t.muted : t.warn], user: ['мой продукт', t.ai1] } as const;
  const [label, color] = map[f.source];
  return <Txt size={11} color={color}>{label}</Txt>;
}

export default function Add() {
  const r = useRouter(); const t = useTheme();
  const { meal = 'b', date } = useLocalSearchParams<{ meal?: string; date?: string }>();
  const { customFoods, foodCache, entries } = useStore();
  const [q, setQ] = useState('');
  const [remote, setRemote] = useState<Food[]>([]);
  const [busy, setBusy] = useState(false);
  const all = useMemo(() => [...Object.values(customFoods), ...SEED_FOODS, ...Object.values(foodCache)], [customFoods, foodCache]);

  // частые продукты — из истории
  const frequent = useMemo(() => {
    const cnt = new Map<string, number>();
    Object.values(entries).forEach(e => e.foodId && cnt.set(e.foodId, (cnt.get(e.foodId) ?? 0) + 1));
    return [...cnt.entries()].sort((a, b) => b[1] - a[1]).map(([id]) => all.find(f => f.id === id)).filter(Boolean).slice(0, 8) as Food[];
  }, [entries, all]);

  const timer = useRef<any>(null);
  useEffect(() => {
    clearTimeout(timer.current); setRemote([]);
    if (q.trim().length < 3) return;
    timer.current = setTimeout(async () => {
      setBusy(true);
      try { const fs = await searchRemote(q.trim()); useStore.getState().cacheFoods(fs); setRemote(fs); } catch {}
      setBusy(false);
    }, 450);
    return () => clearTimeout(timer.current);
  }, [q]);

  const local = useMemo(() => (q.trim() ? searchFoodsLocal(q, all) : frequent.length ? frequent : SEED_FOODS.slice(0, 20)), [q, all, frequent]);
  const data = useMemo(() => { const seen = new Set(local.map(f => f.id)); return [...local, ...remote.filter(f => !seen.has(f.id))]; }, [local, remote]);
  const go = (f: Food) => r.replace({ pathname: '/portion', params: { foodId: f.id, meal, date } });

  return (
    <Screen scroll={false} edges={[]}>
      <View style={[s.row, { gap: 10, marginBottom: 12 }]}>
        <Btn style={{ flex: 1 }} kind="ai" title="✨ Словами" onPress={() => r.replace({ pathname: '/aitext', params: { meal, date } })} />
        <Btn style={{ flex: 1 }} title="▮▯▮ Штрихкод" onPress={() => r.replace({ pathname: '/scan', params: { meal, date } })} />
      </View>
      <Input placeholder="🔍 Поиск продукта…" value={q} onChangeText={setQ} autoFocus={false} />
      <Txt size={11} muted style={{ marginTop: 10, marginBottom: 2 }}>{q.trim() ? `НАЙДЕНО: ${data.length}${busy ? ' · ищу в базе…' : ''}` : frequent.length ? 'ВЫ ЧАСТО ЕДИТЕ' : 'ПОПУЛЯРНОЕ'}</Txt>
      <FlatList data={data} keyExtractor={f => f.id} keyboardShouldPersistTaps="handled"
        ListEmptyComponent={<Txt muted style={{ paddingVertical: 20 }}>{busy ? 'Ищу…' : 'Не найдено. Попробуйте «Словами», штрихкод или создайте свой продукт.'}</Txt>}
        ListFooterComponent={<Btn kind="ghost" style={{ marginTop: 14 }} title="＋ Создать свой продукт" onPress={() => r.replace({ pathname: '/custom', params: { meal, date } })} />}
        renderItem={({ item: f }) => (
          <Pressable onPress={() => go(f)} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 11, borderBottomWidth: 1, borderBottomColor: t.line }}>
            <View style={{ flex: 1 }}>
              <Txt numberOfLines={1}>{f.name}{f.brand ? ` · ${f.brand}` : ''}</Txt>
              <Txt size={12} muted>на 100 г: Б {f.protein} · Ж {f.fat} · У {f.carbs}  </Txt><SourceBadge f={f} />
            </View>
            <Txt bold>{f.kcal}<Txt size={12} muted> ккал</Txt></Txt>
          </Pressable>
        )} />
    </Screen>
  );
}
