import React, { useMemo, useState } from 'react';
import { View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Screen } from '../components/Screen';
import { Btn, Card, Chip, Input, Txt, s, useTheme } from '../ui';
import { lastPortion, useStore } from '../store';
import { SEED_FOODS } from '../core/foods';
import { macroFor, today, r0 } from '../core/nutrition';
import type { Food, MealId } from '../core/types';
import { SourceBadge } from './add';
import { deleteNutrition, writeNutrition } from '../health';

export default function Portion() {
  const r = useRouter(); const t = useTheme();
  const { foodId, entryId, meal = 'b', date } = useLocalSearchParams<{ foodId?: string; entryId?: string; meal?: string; date?: string }>();
  const { customFoods, foodCache, entries, settings } = useStore();
  const entry = entryId ? entries[entryId] : undefined;

  const food: Food | null = useMemo(() => {
    const id = entry?.foodId ?? foodId;
    const found = [...Object.values(customFoods), ...SEED_FOODS, ...Object.values(foodCache)].find(f => f.id === id);
    if (found) return found;
    if (entry) return { id: 'x', name: entry.name, kcal: entry.kcal / entry.grams * 100, protein: entry.protein / entry.grams * 100, fat: entry.fat / entry.grams * 100, carbs: entry.carbs / entry.grams * 100, portionG: entry.grams, unit: 'порция', source: 'user', quality: 1 };
    return null;
  }, [foodId, entry]);

  const initial = entry?.grams ?? (food ? lastPortion(entries, food.id) ?? food.portionG : 100);
  const [g, setG] = useState(String(initial));
  if (!food) return <Screen><Txt>Продукт не найден</Txt></Screen>;
  const grams = Math.max(0, Number(g.replace(',', '.')) || 0);
  const m = macroFor(food, grams);
  const set = (n: number) => setG(String(Math.max(1, r0(n))));
  const remembered = !entry && lastPortion(entries, food.id);

  const save = () => {
    if (!grams) return;
    const st = useStore.getState();
    if (entry) { st.updateEntry(entry.id, grams, food.id === 'x' ? undefined : food); const e = useStore.getState().entries[entry.id]; if (settings.hcWriteNutrition) writeNutrition(e); }
    else { const e = st.addEntry({ date: (date as string) || today(), meal: meal as MealId, food, grams }); if (settings.hcWriteNutrition) writeNutrition(e); }
    r.dismissAll();
  };

  return (
    <Screen>
      <Txt size={22} bold>{food.name}</Txt>
      <View style={{ marginVertical: 6 }}>
        {food.brand ? <Txt muted>{food.brand}</Txt> : null}
        <View style={s.row}><Txt size={12.5} muted>На 100 г: {food.kcal} ккал · Б {food.protein} · Ж {food.fat} · У {food.carbs}   </Txt><SourceBadge f={food} /></View>
      </View>
      {food.source === 'off' && food.quality < 1 && (
        <View style={{ backgroundColor: t.warnSoft, borderRadius: 12, padding: 10, marginBottom: 10 }}>
          <Txt size={12.5} color={t.warn}>Данные этого продукта из открытой базы сходятся не полностью (калории и БЖУ расходятся). Сверьте с упаковкой.</Txt>
        </View>
      )}
      <View style={[s.row, { gap: 10, marginVertical: 12 }]}>
        <Btn small kind="ghost" title="−10" onPress={() => set(grams - 10)} />
        <Input value={g} onChangeText={setG} keyboardType="decimal-pad" style={{ textAlign: 'center', fontSize: 20, fontWeight: '700' }} />
        <Btn small kind="ghost" title="+10" onPress={() => set(grams + 10)} />
        <Txt muted>г</Txt>
      </View>
      <View style={[s.row, { marginBottom: 6 }]}>
        <Chip label="½" onPress={() => set(food.portionG / 2)} />
        <Chip label={`1 ${food.unit} (${r0(food.portionG)} г)`} onPress={() => set(food.portionG)} />
        <Chip label="2×" onPress={() => set(food.portionG * 2)} />
        <Chip label="100 г" onPress={() => set(100)} />
      </View>
      {remembered ? <Txt size={12} muted>Подставили вашу прошлую порцию: {remembered} г</Txt> : null}
      <View style={[s.row, { gap: 8, marginVertical: 16 }]}>
        {([['ккал', m.kcal], ['белки', m.protein], ['жиры', m.fat], ['углев.', m.carbs]] as const).map(([l, v]) => (
          <View key={l} style={{ flex: 1, backgroundColor: t.card, borderRadius: 14, padding: 10, alignItems: 'center' }}><Txt bold size={17}>{v}</Txt><Txt size={11} muted>{l}</Txt></View>
        ))}
      </View>
      <Btn title={entry ? 'Сохранить' : 'Добавить'} onPress={save} />
      {entry && <Btn kind="danger" style={{ marginTop: 10 }} title="Удалить" onPress={() => { useStore.getState().removeEntry(entry.id); if (settings.hcWriteNutrition) deleteNutrition(entry.id); r.back(); }} />}
    </Screen>
  );
}
