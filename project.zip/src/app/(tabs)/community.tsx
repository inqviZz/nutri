import React from 'react';
import { View } from 'react-native';
import { Screen } from '../../components/Screen';
import { Card, Txt } from '../../ui';

export default function Community() {
  return (
    <Screen>
      <Txt size={26} bold style={{ marginVertical: 14 }}>Сообщество</Txt>
      <Card>
        <View style={{ alignItems: 'center', paddingVertical: 20 }}>
          <Txt size={48}>👥</Txt>
          <Txt size={18} bold style={{ marginTop: 8 }}>Скоро</Txt>
          <Txt muted style={{ textAlign: 'center', marginTop: 6 }}>Лента, челленджи и друзья — в следующей версии. Переключатель уже работает: выключите его в «Профиле», и вкладка исчезнет.</Txt>
        </View>
      </Card>
    </Screen>
  );
}
