import React, { useMemo, useState } from 'react';
import { Pressable, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen } from '../../components/Screen';
import { Bar, Btn, Card, Ring, Txt, s, useTheme } from '../../ui';
import { entriesOn, streak, useStore, useTargets } from '../../store';
import { addDays, dateLabel, fmt, r0, sum, targets, today } from '../../core/nutrition';
import { MEALS } from '../../core/types';
import { useHealthAutoRefresh } from '../../healthSync';
import { deleteNutrition } from '../../health';

function insight(left: number, t: ReturnType<typeof targets>, tot: ReturnType<typeof sum>, n: number, water: number) {
  const h = new Date().getHours();
  if (!n) return { ic: '🌅', tx: 'Пока пусто. Напишите, что ели: «овсянка с бананом и кофе с молоком», и AI посчитает КБЖУ.', q: 'Что съесть на завтрак?' };
  if (left < -100) return { ic: '⚠️', tx: `Перебор на ${fmt(-left)} ккал. Один день не ломает прогресс — спросите, как сбалансировать завтра.`, q: 'Я превысил норму. Что делать?' };
  if (tot.protein < t.protein * 0.5 && h >= 13) return { ic: '🥩', tx: `Белка пока ${r0(tot.protein)} г из ${t.protein} г. Подберу ужин, который закроет норму.`, q: 'Что съесть на ужин, чтобы добрать белок?' };
  if (water < t.waterMl * 0.4 && h >= 12) return { ic: '💧', tx: 'Воды пока мало — стакан прямо сейчас?', q: 'Сколько воды мне нужно пить?' };
  return { ic: '👍', tx: `Хороший темп: осталось ${fmt(left)} ккал. Нажмите — сделаю разбор дня.`, q: 'Разбор моего дня' };
}

export default function Diary() {
  const r = useRouter(); const t = useTheme();
  useHealthAutoRefresh();
  const [date, setDate] = useState(today());
  const { profile, entries, water, health, settings } = useStore();
  const T = useTargets();
  const list = useMemo(() => entriesOn(entries, date), [entries, date]);
  const tot = sum(list);
  const act = health[date];
  const bonus = settings.hcEnabled && act ? r0(act.activeKcal * settings.eatBack / 100) : 0;
  const goal = T.kcal + bonus, left = goal - tot.kcal, over = left < 0;
  const wml = water[date]?.ml ?? 0;
  const ins = insight(left, T, tot, list.length, wml);
  const cups = Math.ceil(T.waterMl / 250);

  const macro = (label: string, v: number, tg: number, c: string) => (
    <View style={{ flex: 1 }}>
      <View style={[s.row, { justifyContent: 'space-between', marginBottom: 5 }]}><Txt size={12} muted>{label}</Txt><Txt size={12} muted>{tg} г</Txt></View>
      <Bar value={v} max={tg} color={c} /><Txt bold size={14} style={{ marginTop: 5 }}>{r0(v)} г</Txt>
    </View>
  );

  return (
    <Screen>
      <View style={[s.row, { justifyContent: 'space-between', marginVertical: 12 }]}>
        <View style={s.row}><View style={{ width: 30, height: 30, borderRadius: 10, backgroundColor: t.acc, alignItems: 'center', justifyContent: 'center', marginRight: 8 }}><Txt>🥑</Txt></View><Txt size={20} bold>Nutri</Txt></View>
        <Txt muted>Серия: {streak(entries)} 🔥</Txt>
      </View>

      <View style={[s.row, { justifyContent: 'space-between', marginBottom: 14 }]}>
        <Pressable onPress={() => setDate(addDays(date, -1))} style={{ padding: 10 }}><Txt size={22}>‹</Txt></Pressable>
        <Pressable onPress={() => setDate(today())}><Txt bold>{dateLabel(date)}</Txt></Pressable>
        <Pressable onPress={() => setDate(addDays(date, 1))} style={{ padding: 10 }}><Txt size={22}>›</Txt></Pressable>
      </View>

      <Pressable onPress={() => r.push('/aitext')} style={{ backgroundColor: t.ai1, borderRadius: 18, padding: 14, marginBottom: 14, flexDirection: 'row', alignItems: 'center' }}>
        <Txt size={24} style={{ marginRight: 12 }}>✨</Txt>
        <View style={{ flex: 1 }}><Txt bold color="#fff">Напишите, что съели</Txt><Txt size={12.5} color="#ffffffcc">«Гречка с курицей и салат» — и готово</Txt></View>
      </Pressable>

      <Card>
        <View style={[s.row, { gap: 16 }]}>
          <Ring pct={tot.kcal / goal} over={over}>
            <Txt size={28} bold>{fmt(Math.abs(left))}</Txt><Txt size={12} muted>{over ? 'перебор' : 'осталось'}</Txt>
          </Ring>
          <View style={{ flex: 1, gap: 10 }}>
            <View style={[s.row, { justifyContent: 'space-between' }]}><Txt muted size={13}>Цель</Txt><Txt bold>{fmt(goal)}</Txt></View>
            <View style={[s.row, { justifyContent: 'space-between' }]}><Txt muted size={13}>Съедено</Txt><Txt bold>{fmt(tot.kcal)}</Txt></View>
            {bonus > 0 && <View style={[s.row, { justifyContent: 'space-between' }]}><Txt muted size={13}>За активность</Txt><Txt bold color={t.acc}>+{fmt(bonus)}</Txt></View>}
          </View>
        </View>
        <View style={[s.row, { gap: 12, marginTop: 16 }]}>{macro('Белки', tot.protein, T.protein, t.p)}{macro('Жиры', tot.fat, T.fat, t.f)}{macro('Углеводы', tot.carbs, T.carbs, t.c)}</View>
      </Card>

      {settings.hcEnabled && (
        <Card style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <Txt size={26}>👟</Txt>
          <View style={{ flex: 1 }}>
            <Txt bold>{act ? fmt(act.steps) : '—'} шагов · {act ? fmt(act.activeKcal) : '—'} ккал</Txt>
            <Txt size={12} muted>Samsung Health через Health Connect{settings.eatBack ? ` · +${settings.eatBack}% активных ккал к норме` : ''}</Txt>
          </View>
        </Card>
      )}

      <Pressable onPress={() => r.navigate({ pathname: '/ai', params: { q: ins.q, ts: String(Date.now()) } })} style={{ flexDirection: 'row', gap: 12, backgroundColor: t.aiSoft, borderRadius: 18, padding: 14, marginBottom: 14 }}>
        <Txt size={22}>{ins.ic}</Txt>
        <Txt size={13.5} style={{ flex: 1 }}><Txt bold color={t.ai1}>AI-подсказка{'\n'}</Txt>{ins.tx}</Txt>
      </Pressable>

      {MEALS.map(m => {
        const es = list.filter(e => e.meal === m.id), kc = es.reduce((a, e) => a + e.kcal, 0);
        return (
          <Card key={m.id}>
            <View style={s.row}>
              <View style={{ width: 36, height: 36, borderRadius: 12, backgroundColor: t.accSoft, alignItems: 'center', justifyContent: 'center', marginRight: 10 }}><Txt size={18}>{m.em}</Txt></View>
              <View style={{ flex: 1 }}><Txt bold>{m.name}</Txt><Txt size={12.5} muted>{kc ? fmt(kc) + ' ккал' : '—'}</Txt></View>
              <Pressable onPress={() => r.push({ pathname: '/add', params: { meal: m.id, date } })} style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: t.acc, alignItems: 'center', justifyContent: 'center' }}><Txt color="#fff" size={22}>+</Txt></Pressable>
            </View>
            {es.length === 0 ? <Txt size={13} muted style={{ paddingTop: 8 }}>Ничего не добавлено</Txt> : es.map(e => (
              <Pressable key={e.id} onPress={() => r.push({ pathname: '/portion', params: { entryId: e.id } })}
                onLongPress={() => { useStore.getState().removeEntry(e.id); if (settings.hcWriteNutrition) deleteNutrition(e.id); }}
                style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderTopWidth: 1, borderTopColor: t.line, marginTop: 8 }}>
                <View style={{ flex: 1 }}><Txt numberOfLines={1}>{e.name}</Txt><Txt size={12} muted>{e.grams} г · Б {r0(e.protein)} · Ж {r0(e.fat)} · У {r0(e.carbs)}</Txt></View>
                <Txt bold>{e.kcal}</Txt>
              </Pressable>
            ))}
          </Card>
        );
      })}
      <Txt size={12} muted style={{ textAlign: 'center', marginBottom: 14 }}>Нажмите на запись, чтобы изменить порцию. Долгое нажатие — удалить.</Txt>

      <Card>
        <View style={[s.row, { justifyContent: 'space-between', marginBottom: 10 }]}><Txt bold>💧 Вода</Txt><Txt size={12.5} muted>{wml} / {T.waterMl} мл</Txt></View>
        <View style={[s.row, { gap: 10 }]}>
          <View style={{ flex: 1, flexDirection: 'row', flexWrap: 'wrap', gap: 4 }}>
            {Array.from({ length: cups }, (_, i) => <View key={i} style={{ width: 20, height: 24, borderRadius: 10, backgroundColor: i < wml / 250 ? t.water : t.line }} />)}
          </View>
          <Btn small title="+250" onPress={() => useStore.getState().addWater(date, 250)} />
          <Btn small kind="ghost" title="−" onPress={() => useStore.getState().addWater(date, -250)} />
        </View>
      </Card>
    </Screen>
  );
}
