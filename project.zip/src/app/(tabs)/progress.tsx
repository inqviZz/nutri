import React, { useState } from 'react';
import { Alert, View } from 'react-native';
import { useRouter } from 'expo-router';
import Svg, { Defs, Line, LinearGradient, Path, Rect, Stop, Text as SvgText, Circle } from 'react-native-svg';
import { Screen } from '../../components/Screen';
import { Btn, Card, Input, Txt, s, useTheme } from '../../ui';
import { entriesOn, streak, useStore, useTargets } from '../../store';
import { addDays, fmt, parseKey, r0, r1, sum, targets, today } from '../../core/nutrition';
import { openHealthSettings, writeWeight } from '../../health';
import { refreshHealth } from '../../healthSync';

const W = 320;
export default function Progress() {
  const t = useTheme(); const router = useRouter();
  const { profile, entries, weights, settings, health } = useStore();
  const T = useTargets();
  const days = Array.from({ length: 7 }, (_, i) => addDays(today(), i - 6));
  const vals = days.map(d => sum(entriesOn(entries, d)).kcal);
  const logged = vals.filter(v => v > 0);
  const avg = logged.length ? r0(logged.reduce((a, b) => a + b, 0) / logged.length) : 0;
  const max = Math.max(T.kcal * 1.25, ...vals), H = 130;
  const ty = H - (T.kcal / max) * H;

  const ws = Object.entries(weights).map(([d, w]) => ({ d, ...w })).sort((a, b) => (a.d < b.d ? -1 : 1));
  const cur = ws.length ? ws[ws.length - 1].kg : profile.weight, first = ws.length ? ws[0].kg : cur;
  const [w, setW] = useState(String(cur));

  let wchart: React.ReactNode = <Txt muted>Добавьте хотя бы два взвешивания</Txt>;
  if (ws.length >= 2) {
    const mn = Math.min(...ws.map(x => x.kg), profile.goalWeight) - 1, mx = Math.max(...ws.map(x => x.kg)) + 1, h = 120;
    const pts = ws.map((x, i) => [(i / (ws.length - 1)) * W, h - ((x.kg - mn) / (mx - mn)) * h]);
    const line = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
    const gy = h - ((profile.goalWeight - mn) / (mx - mn)) * h;
    wchart = (
      <Svg viewBox={`0 0 ${W} ${h + 12}`} width="100%" height={150}>
        <Defs><LinearGradient id="wa" x1="0" y1="0" x2="0" y2="1"><Stop offset="0" stopColor="#22c55e" stopOpacity="0.35" /><Stop offset="1" stopColor="#22c55e" stopOpacity="0" /></LinearGradient></Defs>
        <Line x1={0} x2={W} y1={gy} y2={gy} stroke={t.muted} strokeDasharray="4 4" opacity={0.6} />
        <SvgText x={W} y={gy - 5} textAnchor="end" fontSize={10} fill={t.muted}>{`цель ${profile.goalWeight} кг`}</SvgText>
        <Path d={`${line} L${W} ${h} L0 ${h} Z`} fill="url(#wa)" />
        <Path d={line} fill="none" stroke="#16a34a" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" />
        {pts.map((p, i) => <Circle key={i} cx={p[0]} cy={p[1]} r={4} fill={t.card} stroke={ws[i].source === 'health' ? '#2563eb' : '#16a34a'} strokeWidth={2.5} />)}
      </Svg>
    );
  }

  const saveWeight = () => {
    const kg = Number(w.replace(',', '.')); if (!kg) return;
    useStore.getState().setWeight(today(), kg, 'manual');
    if (settings.hcEnabled && settings.hcWriteWeight) writeWeight(today(), kg);
  };
  const steps = days.map(d => health[d]?.steps ?? 0);

  return (
    <Screen>
      <Txt size={26} bold style={{ marginVertical: 12 }}>Прогресс</Txt>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 14 }}>
        {[
          ['Текущий вес', `${r1(cur)} кг`, `${cur <= first ? '▼' : '▲'} ${Math.abs(r1(cur - first))} кг всего`],
          ['До цели', `${Math.abs(r1(cur - profile.goalWeight))} кг`, `цель ${profile.goalWeight} кг`],
          ['Серия', `${streak(entries)} 🔥`, 'дней подряд'],
          ['Среднее за неделю', fmt(avg), 'ккал / день'],
        ].map(([a, b, c]) => <Card key={a} style={{ width: '48%', marginBottom: 0, padding: 14 }}><Txt size={12} muted>{a}</Txt><Txt size={22} bold>{b}</Txt><Txt size={12} muted>{c}</Txt></Card>)}
      </View>

      <View style={[s.row, { gap: 10, marginBottom: 14 }]}>
        <Btn style={{ flex: 1 }} kind="ghost" title="📏 Замеры тела" onPress={() => router.push('/measures')} />
        <Btn style={{ flex: 1 }} kind="ghost" title="🧬 Состав и норма" onPress={() => router.push('/body')} />
      </View>

      <Card>
        <Txt size={18} bold style={{ marginBottom: 8 }}>Калории за 7 дней</Txt>
        <Svg viewBox={`0 0 ${W} ${H + 24}`} width="100%" height={170}>
          <Defs><LinearGradient id="ba" x1="0" y1="0" x2="0" y2="1"><Stop offset="0" stopColor="#22c55e" /><Stop offset="1" stopColor="#14b8a6" /></LinearGradient></Defs>
          <Line x1={0} x2={W} y1={ty} y2={ty} stroke={t.muted} strokeDasharray="4 4" opacity={0.6} />
          <SvgText x={0} y={ty - 5} fontSize={10} fill={t.muted}>{`цель ${fmt(T.kcal)}`}</SvgText>
          {days.map((k, i) => {
            const bw = 26, gap = (W - 7 * bw) / 6, x = i * (bw + gap), h = (vals[i] / max) * H;
            return (
              <React.Fragment key={k}>
                <Rect x={x} y={H - h} width={bw} height={Math.max(h, vals[i] ? 3 : 0)} rx={8} fill={vals[i] > T.kcal * 1.05 ? '#f97316' : 'url(#ba)'} />
                <SvgText x={x + bw / 2} y={H + 18} textAnchor="middle" fontSize={11} fill={t.muted}>{['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'][parseKey(k).getDay()]}</SvgText>
              </React.Fragment>
            );
          })}
        </Svg>
      </Card>

      {settings.hcEnabled && (
        <Card>
          <Txt size={18} bold style={{ marginBottom: 4 }}>👟 Шаги (Samsung Health)</Txt>
          <Txt muted size={13}>За 7 дней: {fmt(steps.reduce((a, b) => a + b, 0))} · в среднем {fmt(steps.reduce((a, b) => a + b, 0) / 7)} в день</Txt>
        </Card>
      )}

      <Card>
        <Txt size={18} bold style={{ marginBottom: 8 }}>Динамика веса</Txt>
        {wchart}
        {settings.hcEnabled && !ws.some(x => x.source === 'health') && (
          <View style={{ marginTop: 10, padding: 10, borderRadius: 12, backgroundColor: t.warnSoft }}>
            <Txt size={13} color={t.warn}>Вес из Samsung Health пока не приходит. Скорее всего, Samsung Health не передаёт его в Health Connect: Samsung Health → Настройки → Health Connect → включите «Вес» (и убедитесь, что вес записан в самом Samsung Health).</Txt>
            <View style={[s.row, { gap: 8, marginTop: 8 }]}><Btn small kind="ghost" title="Открыть Health Connect" onPress={openHealthSettings} /><Btn small kind="ghost" title="Проверить снова" onPress={async () => { await refreshHealth(); Alert.alert(Object.values(useStore.getState().weights).some(x => x.source === 'health') ? 'Вес найден ✓' : 'Пока ничего не найдено'); }} /></View>
          </View>
        )}
        <Txt size={11.5} muted style={{ marginTop: 4 }}>● зелёные точки — ввод вручную{settings.hcEnabled ? ' · синие — из Samsung Health' : ''}</Txt>
        <View style={[s.row, { gap: 10, marginTop: 12 }]}>
          <Input value={w} onChangeText={setW} keyboardType="decimal-pad" />
          <Btn title="Записать вес" onPress={saveWeight} style={{ paddingHorizontal: 18 }} />
        </View>
      </Card>
    </Screen>
  );
}
