import React, { useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { Screen } from '../../components/Screen';
import { Btn, Card, Chip, Input, Txt, s, useTheme } from '../../ui';
import { useStore, useTargets } from '../../store';
import { fmt, targets, addDays, today } from '../../core/nutrition';
import { SEED_FOODS } from '../../core/foods';
import { login, syncNow } from '../../api';
import { connectHealth, healthSupported, openHealthSettings, writeWeight } from '../../health';
import { refreshHealth } from '../../healthSync';
import type { Profile } from '../../core/types';
import { useRouter } from 'expo-router';
import { LLM_PRESETS, callLlm, llmConfigured } from '../../llm';

const Switch = ({ on, onPress }: { on: boolean; onPress: () => void }) => {
  const t = useTheme();
  return <Pressable onPress={onPress} style={{ width: 50, height: 30, borderRadius: 15, backgroundColor: on ? t.acc : t.line, justifyContent: 'center' }}><View style={{ width: 24, height: 24, borderRadius: 12, backgroundColor: '#fff', marginLeft: on ? 23 : 3 }} /></Pressable>;
};
const Row = ({ title, sub, right }: { title: string; sub?: string; right: React.ReactNode }) => {
  const t = useTheme();
  return <View style={[s.row, { paddingVertical: 12, borderTopWidth: 1, borderTopColor: t.line, gap: 12 }]}><View style={{ flex: 1 }}><Txt bold>{title}</Txt>{sub ? <Txt size={12.5} muted>{sub}</Txt> : null}</View>{right}</View>;
};
const H2 = ({ children }: { children: string }) => <Txt size={18} bold style={{ marginBottom: 8 }}>{children}</Txt>;

export default function Settings() {
  const t = useTheme(); const router = useRouter();
  const { profile, settings, token, email, healthSyncedAt, outbox } = useStore();
  const T = useTargets();
  const [p, setP] = useState({ name: profile.name, age: String(profile.age), height: String(profile.height), weight: String(profile.weight), goalWeight: String(profile.goalWeight) });
  const [sex, setSex] = useState(profile.sex); const [goal, setGoal] = useState(profile.goal); const [act, setAct] = useState(profile.activity);
  const [em, setEm] = useState(email ?? ''); const [pw, setPw] = useState(''); const [url, setUrl] = useState(settings.serverUrl);
  const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false);
  const set = useStore.getState().setSettings;
  const [key, setKey] = useState(settings.llmKey ?? ''); const [lurl, setLurl] = useState(settings.llmUrl ?? ''); const [lmodel, setLmodel] = useState(settings.llmModel ?? '');
  const [aimsg, setAimsg] = useState('');
  const preset = LLM_PRESETS.find(x => x.id === settings.llmPreset);
  const pickPreset = (id: string) => { const pr = LLM_PRESETS.find(x => x.id === id)!; set({ llmPreset: id }); if (id !== 'custom') { setLurl(pr.url); setLmodel(pr.model); } };
  const saveAi = async () => {
    set({ llmKey: key.trim(), llmUrl: lurl.trim(), llmModel: lmodel.trim() }); setAimsg('Проверяю…');
    try { const a = await callLlm([{ role: 'user', content: 'Ответь одним словом: «готово».' }], 0, 20000); setAimsg('✅ AI отвечает: ' + a.slice(0, 60)); }
    catch (e: any) { setAimsg('❌ ' + (e?.message ?? 'ошибка') + '. Проверьте ключ, адрес и название модели.'); }
  };
  const n = (v: string, d: number) => Number(v.replace(',', '.')) || d;

  const saveProfile = () => {
    const np: Partial<Profile> = { name: p.name || 'Друг', sex, goal, activity: act, age: n(p.age, 30), height: n(p.height, 170), weight: n(p.weight, 70), goalWeight: n(p.goalWeight, 70) };
    useStore.getState().saveProfile(np); Alert.alert('Норма пересчитана ✓');
  };
  const auth = async (mode: 'login' | 'register') => {
    setBusy(true); setMsg('');
    try { set({ serverUrl: url.trim() }); await login(mode, em.trim(), pw); const r = await syncNow(); setMsg(`Готово: отправлено ${r.pushed}, получено ${r.pulled}`); setPw(''); }
    catch (e: any) { setMsg(({ no_server: 'Укажите адрес сервера', wrong_credentials: 'Неверная почта или пароль', email_taken: 'Почта уже занята', invalid_credentials: 'Проверьте почту и пароль (от 8 символов)' } as any)[e.message] ?? 'Не удалось подключиться: ' + e.message); }
    setBusy(false);
  };
  const doSync = async () => { setBusy(true); try { const r = await syncNow(); setMsg(`Синхронизировано: ↑${r.pushed} ↓${r.pulled}`); } catch (e: any) { setMsg('Ошибка синхронизации: ' + e.message); } setBusy(false); };

  const connect = async () => {
    setBusy(true);
    const res = await connectHealth({ writeWeight: settings.hcWriteWeight, writeNutrition: settings.hcWriteNutrition });
    if (res.ok) { set({ hcEnabled: true }); await refreshHealth(); setMsg('Samsung Health подключён ✓'); }
    else setMsg(({ unsupported: 'Health Connect доступен только на Android', unavailable: 'Health Connect не установлен (Android 13 и ниже: установите из Google Play; Android 14+: включён в систему)', update_required: 'Обновите Health Connect в Google Play', denied: 'Доступ не выдан. Разрешите чтение шагов и активности', error: 'Ошибка: ' + (res.message ?? '') } as any)[res.reason]);
    setBusy(false);
  };

  const demo = () => {
    const st = useStore.getState(); let x = 11; const rnd = () => (x = (x * 9301 + 49297) % 233280) / 233280;
    const pool: Record<string, string[]> = { b: ['oat', 'omel', 'cott5', 'egg', 'yog', 'coff'], l: ['buck', 'chbr', 'bors', 'rice', 'sal', 'soup'], d: ['salm', 'sal', 'chth', 'pot', 'brc'], s: ['app', 'ban', 'alm', 'bar'] };
    for (let i = 1; i <= 6; i++) for (const m of ['b', 'l', 'd', 's'] as const) {
      const id = 'seed:' + pool[m][Math.floor(rnd() * pool[m].length)], f = SEED_FOODS.find(z => z.id === id)!;
      st.addEntry({ date: addDays(today(), -i), meal: m, food: f, grams: Math.round(f.portionG * (0.8 + rnd() * 0.5)) });
    }
    [84.6, 84.1, 83.6, 83.2, 82.9, 82.5].forEach((kg, i) => st.setWeight(addDays(today(), -(5 - i) * 5), kg));
    Alert.alert('Демо-данные добавлены');
  };

  return (
    <Screen>
      <Txt size={26} bold style={{ marginVertical: 12 }}>Профиль</Txt>

      <Card>
        <H2>Параметры и норма</H2>
        <Txt muted size={13} style={{ marginBottom: 10 }}>Сейчас: {fmt(T.kcal)} ккал · Б {T.protein} · Ж {T.fat} · У {T.carbs} (расход ≈ {fmt(T.tdee)})</Txt>
        <Input label="Имя" value={p.name} onChangeText={v => setP({ ...p, name: v })} />
        <View style={[s.row, { marginTop: 10 }]}><Chip label="Мужской" on={sex === 'm'} onPress={() => setSex('m')} /><Chip label="Женский" on={sex === 'f'} onPress={() => setSex('f')} /></View>
        <View style={[s.row, { gap: 10, marginTop: 10 }]}><Input label="Возраст" keyboardType="number-pad" value={p.age} onChangeText={v => setP({ ...p, age: v })} /><Input label="Рост, см" keyboardType="number-pad" value={p.height} onChangeText={v => setP({ ...p, height: v })} /></View>
        <View style={[s.row, { gap: 10, marginTop: 10 }]}><Input label="Вес, кг" keyboardType="decimal-pad" value={p.weight} onChangeText={v => setP({ ...p, weight: v })} /><Input label="Цель, кг" keyboardType="decimal-pad" value={p.goalWeight} onChangeText={v => setP({ ...p, goalWeight: v })} /></View>
        <View style={[s.row, { flexWrap: 'wrap', marginTop: 10, rowGap: 8 }]}>{([['lose', 'Похудеть'], ['keep', 'Поддерживать'], ['gain', 'Набрать']] as const).map(([k, l]) => <Chip key={k} label={l} on={goal === k} onPress={() => setGoal(k)} />)}</View>
        <View style={[s.row, { flexWrap: 'wrap', marginTop: 8, rowGap: 8 }]}>{([[1.2, 'Сидячий'], [1.375, 'Лёгкая'], [1.55, 'Средняя'], [1.725, 'Высокая']] as const).map(([k, l]) => <Chip key={k} label={'Активность: ' + l} on={act === k} onPress={() => setAct(k)} />)}</View>
        <Btn style={{ marginTop: 14 }} title="Сохранить и пересчитать" onPress={saveProfile} />
      </Card>

      <Card>
        <H2>Samsung Health</H2>
        <Txt muted size={13}>Подключение идёт через Health Connect: Samsung Health (и часы Galaxy Watch) отдают шаги, активные калории и вес. В Samsung Health должна быть включена синхронизация: Настройки → Health Connect.</Txt>
        {!healthSupported() ? <Txt size={13} color={t.warn} style={{ marginTop: 8 }}>Доступно только в Android-приложении.</Txt> : (
          <>
            <Row title={settings.hcEnabled ? 'Подключено' : 'Не подключено'} sub={healthSyncedAt ? 'Обновлено: ' + new Date(healthSyncedAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) : undefined}
              right={settings.hcEnabled ? <Btn small kind="ghost" title="Обновить" onPress={() => refreshHealth()} /> : <Btn small title="Подключить" onPress={connect} disabled={busy} />} />
            {settings.hcEnabled && <>
              <View style={{ paddingVertical: 10 }}>
                <Txt bold>Добавлять сожжённые калории к норме</Txt>
                <View style={[s.row, { marginTop: 8 }]}>{([[0, 'Нет'], [50, '50%'], [100, '100%']] as const).map(([v, l]) => <Chip key={v} label={l} on={settings.eatBack === v} onPress={() => set({ eatBack: v })} />)}</View>
                <Txt size={12} muted style={{ marginTop: 4 }}>Часы обычно завышают расход — 50% безопаснее.</Txt>
              </View>
              <Row title="Записывать мой вес в Health Connect" right={<Switch on={settings.hcWriteWeight} onPress={() => { set({ hcWriteWeight: !settings.hcWriteWeight }); if (!settings.hcWriteWeight) connectHealth({ writeWeight: true, writeNutrition: settings.hcWriteNutrition }); }} />} />
              <Row title="Записывать съеденное в Health Connect" sub="Калории и БЖУ приёмов пищи (идемпотентно, без дублей)" right={<Switch on={settings.hcWriteNutrition} onPress={() => { set({ hcWriteNutrition: !settings.hcWriteNutrition }); if (!settings.hcWriteNutrition) connectHealth({ writeWeight: settings.hcWriteWeight, writeNutrition: true }); }} />} />
              <View style={[s.row, { gap: 10, marginTop: 8 }]}><Btn small kind="ghost" title="Настройки Health Connect" onPress={openHealthSettings} /><Btn small kind="ghost" title="Отключить" onPress={() => set({ hcEnabled: false })} /></View>
            </>}
          </>
        )}
        {msg ? <Txt size={12.5} color={t.ai1} style={{ marginTop: 8 }}>{msg}</Txt> : null}
      </Card>

      <Card>
        <H2>✨ AI-тренер (языковая модель)</H2>
        <Txt muted size={13} style={{ marginBottom: 10 }}>Без ключа приложение отвечает по встроенным правилам. С ключом включается настоящая языковая модель: разбор «съел…» и диалог с тренером. Ключ хранится только на этом телефоне.</Txt>
        <View style={[s.row, { flexWrap: 'wrap', rowGap: 8 }]}>{LLM_PRESETS.map(x => <Chip key={x.id} label={x.label} on={settings.llmPreset === x.id} onPress={() => pickPreset(x.id)} />)}</View>
        {preset ? <Txt size={12} muted style={{ marginTop: 8 }}>{preset.hint}</Txt> : null}
        {settings.llmPreset ? (
          <View style={{ marginTop: 10, gap: 10 }}>
            <Input label="API-ключ" value={key} onChangeText={setKey} secureTextEntry autoCapitalize="none" placeholder="sk-…" />
            <Input label="Адрес (.../chat/completions)" value={lurl} onChangeText={setLurl} autoCapitalize="none" />
            <Input label="Модель" value={lmodel} onChangeText={setLmodel} autoCapitalize="none" />
            <Btn kind="ai" title="Сохранить и проверить" onPress={saveAi} />
          </View>
        ) : null}
        {aimsg ? <Txt size={12.5} style={{ marginTop: 8 }}>{aimsg}</Txt> : llmConfigured() ? <Txt size={12.5} color={t.acc} style={{ marginTop: 8 }}>AI-модель подключена</Txt> : null}
      </Card>

      <Card>
        <H2>Аккаунт и синхронизация</H2>
        {token ? (
          <>
            <Txt>Вы вошли как <Txt bold>{email}</Txt></Txt>
            <Txt size={12.5} muted style={{ marginVertical: 6 }}>Несинхронизированных изменений: {Object.keys(outbox).length}</Txt>
            <View style={[s.row, { gap: 10 }]}><Btn small title="Синхронизировать" onPress={doSync} disabled={busy} /><Btn small kind="ghost" title="Выйти" onPress={() => useStore.getState().setAuth(null, null)} /></View>
          </>
        ) : (
          <>
            <Txt muted size={13} style={{ marginBottom: 10 }}>Без аккаунта всё работает офлайн на этом телефоне. Аккаунт нужен для синхронизации между устройствами, AI через сервер и общей базы продуктов.</Txt>
            <Input label="Адрес сервера" value={url} onChangeText={setUrl} autoCapitalize="none" placeholder="http://192.168.1.10:8787" />
            <View style={[s.row, { gap: 10, marginTop: 10 }]}><Input label="Почта" value={em} onChangeText={setEm} autoCapitalize="none" keyboardType="email-address" /><Input label="Пароль" value={pw} onChangeText={setPw} secureTextEntry /></View>
            <View style={[s.row, { gap: 10, marginTop: 12 }]}><Btn small title="Войти" onPress={() => auth('login')} disabled={busy} /><Btn small kind="ghost" title="Регистрация" onPress={() => auth('register')} disabled={busy} /></View>
          </>
        )}
      </Card>

      <Card>
        <H2>Приложение</H2>
        <Row title="Социальная сеть" sub={settings.social ? 'Включена: появилась вкладка «Сообщество» (пока заглушка)' : 'Выключена: только личный дневник'} right={<Switch on={settings.social} onPress={() => set({ social: !settings.social })} />} />
        <View style={{ paddingVertical: 10, borderTopWidth: 1, borderTopColor: t.line }}>
          <Txt bold>Тема</Txt>
          <View style={[s.row, { marginTop: 8 }]}>{([['system', 'Системная'], ['light', 'Светлая'], ['dark', 'Тёмная']] as const).map(([k, l]) => <Chip key={k} label={l} on={settings.theme === k} onPress={() => set({ theme: k })} />)}</View>
        </View>
      </Card>

      <Card>
        <H2>🧪 Тестирование</H2>
        <Txt muted size={13} style={{ marginBottom: 10 }}>Автопроверка всех функций и готовый отчёт, который можно отправить разработчику одним нажатием.</Txt>
        <Btn title="Проверка и отчёт" onPress={() => router.push('/diagnostics')} />
      </Card>

      <Card>
        <H2>Данные</H2>
        <View style={[s.row, { gap: 10 }]}><Btn small kind="ghost" title="Заполнить демо-данными" onPress={demo} /><Btn small kind="danger" title="Стереть всё" onPress={() => Alert.alert('Стереть все локальные данные?', '', [{ text: 'Отмена' }, { text: 'Стереть', style: 'destructive', onPress: () => useStore.getState().resetAll() }])} /></View>
      </Card>
    </Screen>
  );
}
