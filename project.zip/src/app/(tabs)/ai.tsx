import React, { useEffect, useRef, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, TextInput, View } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Chip, Txt, s, useTheme } from '../../ui';
import { currentTargets, entriesOn, useStore } from '../../store';
import { today } from '../../core/nutrition';
import { contextString, localAnswer, type CoachCtx } from '../../core/coach';
import { aiChat } from '../../api';
import { llmConfigured } from '../../llm';

const QUICK = ['Разбор моего дня', 'Что съесть на ужин?', 'Сколько мне осталось?', 'Лёгкий перекус', 'Сколько пить воды?', 'Разбор недели'];
type Msg = { r: 'me' | 'ai'; t: string };

export default function AI() {
  const t = useTheme(); const { q, ts } = useLocalSearchParams<{ q?: string; ts?: string }>();
  const [chat, setChat] = useState<Msg[]>([]); const [busy, setBusy] = useState(false); const [input, setInput] = useState('');
  const scroll = useRef<ScrollView>(null); const lastTs = useRef<string | undefined>(undefined);

  const ask = async (text: string) => {
    if (!text.trim() || busy) return;
    const st = useStore.getState();
    const ctx: CoachCtx = { profile: st.profile, allEntries: st.entries, entries: entriesOn(st.entries, today()), waterMl: st.water[today()]?.ml ?? 0, activeKcal: st.health[today()]?.activeKcal, T: currentTargets() };
    const next = [...chat, { r: 'me' as const, t: text }]; setChat(next); setBusy(true); setInput('');
    const remote = await aiChat(next.slice(-8).map(m => ({ role: m.r === 'me' ? 'user' : 'assistant', content: m.t })), contextString(ctx));
    if (!remote) await new Promise(r => setTimeout(r, 600));
    setChat(c => [...c, { r: 'ai', t: remote ?? ((llmConfigured() ? '⚠️ AI-модель не ответила (подробности — в Профиль → Проверка и отчёт). Отвечаю по встроенным правилам.\n\n' : '') + localAnswer(text, ctx)) }]); setBusy(false);
  };
  useEffect(() => { if (q && ts !== lastTs.current) { lastTs.current = ts; ask(q); } }, [q, ts]);
  useEffect(() => { setTimeout(() => scroll.current?.scrollToEnd({ animated: true }), 50); }, [chat, busy]);

  return (
    <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: t.bg }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView ref={scroll} contentContainerStyle={{ padding: 16 }}>
          <Txt size={26} bold style={{ marginVertical: 12 }}>✨ AI-помощник</Txt>
          {chat.length === 0 && <View style={{ alignItems: 'center', paddingVertical: 20 }}><Txt size={54}>🥑</Txt><Txt muted style={{ textAlign: 'center', marginTop: 6 }}>Я знаю ваши цели и дневник. Спросите что угодно о питании.</Txt></View>}
          {chat.map((m, i) => (
            <View key={i} style={{ alignSelf: m.r === 'me' ? 'flex-end' : 'flex-start', maxWidth: '86%', marginBottom: 10, padding: 12, borderRadius: 18, backgroundColor: m.r === 'me' ? t.ai1 : t.card }}>
              <Txt color={m.r === 'me' ? '#fff' : t.text}>{m.t}</Txt>
            </View>
          ))}
          {busy && <Txt muted>печатает…</Txt>}
        </ScrollView>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0, paddingHorizontal: 12 }}>{QUICK.map(x => <Chip key={x} label={x} onPress={() => ask(x)} />)}</ScrollView>
        <View style={[s.row, { padding: 12, gap: 8 }]}>
          <TextInput value={input} onChangeText={setInput} onSubmitEditing={() => ask(input)} placeholder="Спросите что-нибудь…" placeholderTextColor={t.muted}
            style={{ flex: 1, backgroundColor: t.card, color: t.text, borderRadius: 99, paddingHorizontal: 18, paddingVertical: 12, fontSize: 15 }} />
          <Pressable onPress={() => ask(input)} style={{ width: 46, height: 46, borderRadius: 23, backgroundColor: t.ai1, alignItems: 'center', justifyContent: 'center' }}><Txt color="#fff" size={18}>➤</Txt></Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
