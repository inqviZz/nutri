import React from 'react';
import { Text } from 'react-native';
import { Tabs } from 'expo-router/js-tabs';
import { useStore } from '../../store';
import { useTheme } from '../../ui';

const icon = (e: string) => ({ focused }: { focused: boolean }) => <Text style={{ fontSize: 21, opacity: focused ? 1 : 0.55 }}>{e}</Text>;

export default function TabsLayout() {
  const t = useTheme();
  const social = useStore(s => s.settings.social);
  return (
    <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: t.acc, tabBarInactiveTintColor: t.muted, tabBarStyle: { backgroundColor: t.card, borderTopColor: t.line } }}>
      <Tabs.Screen name="index" options={{ title: 'Дневник', tabBarIcon: icon('📒') }} />
      <Tabs.Screen name="progress" options={{ title: 'Прогресс', tabBarIcon: icon('📈') }} />
      <Tabs.Screen name="ai" options={{ title: 'AI', tabBarIcon: icon('✨'), tabBarActiveTintColor: t.ai1 }} />
      {/* Вкладка появляется только при включённой соцсети */}
      <Tabs.Screen name="community" options={{ title: 'Сообщество', tabBarIcon: icon('👥'), href: social ? undefined : null }} />
      <Tabs.Screen name="settings" options={{ title: 'Профиль', tabBarIcon: icon('⚙️') }} />
    </Tabs>
  );
}
