import React, { useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Screen } from '../components/Screen';
import { Btn, Card, Chip, Input, Txt, s, useTheme } from '../ui';
import { useStore } from '../store';
import { SEED_FOODS } from '../core/foods';
import { matchFood, parseText, rowMacro, type ParsedRow, type Precision } from '../core/parser';
import { guessMeal, today, macroFor, r0 } from '../core/nutrition';
import { MEALS, type MealId } from '../core/types';
import { aiParse, searchRemote, serverConfigured } from '../api';
import { writeNutrition } from '../health';
import { llmConfigured } from '../llm';

const EXAMPLES = ['овсянка с бананом и кофе с молоком', '200 г гречки, 2 котлеты и салат', 'пицца 2 куска и кола', 'творог 150 г, яблоко, горсть орехов'];

export default function AiText() {
  const r = useRouter(); const t = useTheme();
  const { meal: mealParam, date } = useLocalSearchParams<{ meal?: string; date?: string }>();
  const { customFoods, foodCache, token, settings } = useStore();
  const all = useMemo(() => [...Object.values(customFoods), ...SEED_FOODS, ...Object.values(foodCache)], [customFoods, foodCache]);
  const [text, setText] = useState('');
  const [meal, setMeal] = useState<MealId>((mealParam as MealId) || guessMeal());
  const [rows, setRows] = useState<ParsedRow[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<'llm' | 'local'>('local');

  const run = async (txt = text) => {
    if (!txt.trim()) return;
    setText(txt); setBusy(true);
    const mw = MEALS.find(m => m.words.some(w => txt.toLowerCase().includes(w))); if (mw) setMeal(mw.id);
    const remote = await aiParse(txt);
    if (remote) {
      // LLM даёт только названия и граммы; КБЖУ берём из базы продуктов — так цифры не «выдумываются».
      const out: ParsedRow[] = [];
      for (const it of remote) {
        let food = matchFood(it.name, all);
        if (!food) { try { const fs = await searchRemote(it.name); if (fs.length) { useStore.getState().cacheFoods(fs); food = fs[0]; } } catch {} }
        out.push({ food, label: it.name, grams: Math.round(it.grams), precision: it.assumed ? 'guess' : 'exact' });
      }
      setRows(out); setMode('llm');
    } else { setRows(parseText(txt, all)); setMode('local'); }
    setBusy(false);
  };

  const setGrams = (i: number, v: string) => setRows(rs => rs!.map((x, j) => (j === i ? { ...x, grams: Number(v.replace(',', '.')) || 0, precision: 'exact' as Precision } : x)));
  const valid = rows?.filter(x => x.food) ?? [];
  const total = valid.reduce((a, x) => a + rowMacro(x).kcal, 0);
  const uncertain = valid.filter(x => x.precision !== 'exact').length;

  const addAll = () => {
    const st = useStore.getState();
    valid.forEach(x => { const e = st.addEntry({ date: (date as string) || today(), meal, food: x.food!, grams: x.grams }); if (settings.hcWriteNutrition) writeNutrition(e); });
    r.dismissAll();
  };
  const badge = (p: Precision) => p === 'exact' ? ['✓ вес указан', t.acc] : p === 'standard' ? ['стандартная порция', t.muted] : ['⚠ вес оценён — уточните', t.warn];

  return (
    <Screen>
      <Input multiline numberOfLines={3} value={text} onChangeText={setText} placeholder="На обед был борщ со сметаной, 2 куска хлеба и компот…" style={{ minHeight: 84, textAlignVertical: 'top' }} />
      <View style={[s.row, { flexWrap: 'wrap', marginTop: 10, rowGap: 8 }]}>{MEALS.map(m => <Chip key={m.id} label={`${m.em} ${m.name}`} on={meal === m.id} onPress={() => setMeal(m.id)} />)}</View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginVertical: 10, flexGrow: 0 }}>{EXAMPLES.map(x => <Chip key={x} label={x} onPress={() => run(x)} />)}</ScrollView>
      <Btn kind="ai" title="Распознать" onPress={() => run()} />
      <Txt size={11.5} muted style={{ marginTop: 8 }}>{llmConfigured() ? 'Разбор через AI-модель; калории считаются по базе продуктов.' : token && serverConfigured() ? 'Разбор через AI на сервере; калории считаются по базе продуктов.' : 'Офлайн-разбор по встроенной базе. Войдите в аккаунт и подключите сервер — включится LLM.'}</Txt>

      {busy && <ActivityIndicator style={{ marginTop: 20 }} />}
      {rows && !busy && (
        <View style={{ marginTop: 16 }}>
          {rows.length === 0 && <Txt muted>Ничего не распознано. Назовите продукты проще или найдите через поиск / штрихкод.</Txt>}
          {rows.map((x, i) => x.food ? (
            <Card key={i} style={{ padding: 12, marginBottom: 8, borderWidth: x.precision === 'guess' ? 1.5 : 0, borderColor: t.warn }}>
              <View style={s.row}>
                <View style={{ flex: 1 }}>
                  <Txt numberOfLines={1}>{x.food.name}</Txt>
                  <Txt size={12} muted>{rowMacro(x).kcal} ккал · Б {r0(rowMacro(x).protein)} · Ж {r0(rowMacro(x).fat)} · У {r0(rowMacro(x).carbs)}</Txt>
                  <Txt size={11.5} color={badge(x.precision)[1]}>{badge(x.precision)[0]}</Txt>
                </View>
                <View style={{ width: 84 }}><Input value={String(x.grams)} keyboardType="decimal-pad" onChangeText={v => setGrams(i, v)} style={{ textAlign: 'center', paddingVertical: 8 }} /></View>
                <Txt muted style={{ marginHorizontal: 6 }}>г</Txt>
                <Pressable onPress={() => setRows(rs => rs!.filter((_, j) => j !== i))}><Txt size={18} muted>✕</Txt></Pressable>
              </View>
            </Card>
          ) : (
            <Card key={i} style={{ padding: 12, marginBottom: 8 }}>
              <Txt>«{x.label}»</Txt><Txt size={12} muted>не нашли в базе — найдите через поиск или штрихкод</Txt>
            </Card>
          ))}
          {valid.length > 0 && (
            <>
              {uncertain > 0 && <Txt size={12.5} color={t.warn} style={{ marginBottom: 8 }}>Позиций с примерным весом: {uncertain}. Кухонные весы или названный вес дадут точнее — поправьте граммы выше.</Txt>}
              <Btn title={`Добавить всё · ${total} ккал`} onPress={addAll} />
            </>
          )}
        </View>
      )}
    </Screen>
  );
}
