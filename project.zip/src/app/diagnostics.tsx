import React, { useState } from 'react';
import { ActivityIndicator, Alert, Platform, Share, View } from 'react-native';
import Constants from 'expo-constants';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Clipboard from 'expo-clipboard';
import * as Sharing from 'expo-sharing';
import { File, Paths } from 'expo-file-system';
import { Camera } from 'expo-camera';
import { Screen } from '../components/Screen';
import { Btn, Card, Chip, Input, Txt, s, useTheme } from '../ui';
import { entriesOn, streak, useStore } from '../store';
import { addDays, today, sum } from '../core/nutrition';
import { SEED_FOODS } from '../core/foods';
import { parseText } from '../core/parser';
import { offBarcode } from '../core/off';
import { healthDiagnostics } from '../health';
import { callLlm, llmConfigured, llmParse } from '../llm';
import { serverConfigured } from '../api';
import { clearLog, getLog } from '../diag';

type Res = { name: string; status: 'ok' | 'warn' | 'fail' | 'skip'; detail: string };
const ICON = { ok: '✅', warn: '⚠️', fail: '❌', skip: '➖' } as const;

const MANUAL = [
  'Сканер находит продукты с моей кухни (напишите, сколько из скольких нашлось)',
  'Ввод «словами» понимает мои фразы',
  'Шаги в приложении совпадают с Samsung Health (±10%)',
  'Вес из Samsung Health подтянулся (в графике веса есть точки с пометкой Health Connect)',
  'Замеры тела: сохраняются, график и разница с прошлым раз показываются',
  'Состав тела: ввод вручную и «Взять из Health Connect» работают, норма калорий объясняется понятно',
  'Фото анализов: значения распознались верно (или поправились при подтверждении)',
  'Поиск еды: нашлись привычные продукты (напишите, чего не хватило)',
  'Всё читается, ничего не обрезано и не налезает',
  'AI-тренер отвечает по делу',
  'Переключатель соцсети скрывает/показывает вкладку',
];

async function time<T>(f: () => Promise<T>): Promise<[T, number]> { const t0 = Date.now(); const r = await f(); return [r, Date.now() - t0]; }

export default function Diagnostics() {
  const t = useTheme();
  const st = useStore();
  const [res, setRes] = useState<Res[]>([]);
  const [busy, setBusy] = useState(false);
  const [manual, setManual] = useState<Record<number, 'ok' | 'bad'>>({});
  const [notes, setNotes] = useState<Record<number, string>>({});
  const [free, setFree] = useState('');
  const [done, setDone] = useState(false);

  const run = async () => {
    setBusy(true); setRes([]); setDone(false);
    const out: Res[] = []; const push = (r: Res) => { out.push(r); setRes([...out]); };
    const check = async (name: string, f: () => Promise<Omit<Res, 'name'>>) => { try { push({ name, ...(await f()) }); } catch (e: any) { push({ name, status: 'fail', detail: String(e?.message ?? e).slice(0, 200) }); } };

    await check('Устройство', async () => ({ status: 'ok', detail: `${Platform.OS} ${Platform.Version}; ${(Platform as any).constants?.Brand ?? ''} ${(Platform as any).constants?.Model ?? ''}; приложение ${Constants.expoConfig?.version}` }));
    await check('Память приложения', async () => { await AsyncStorage.setItem('diag', '1'); const v = await AsyncStorage.getItem('diag'); return { status: v === '1' ? 'ok' : 'fail', detail: v === '1' ? 'запись и чтение работают' : 'не читается' }; });
    await check('Интернет и база Open Food Facts', async () => {
      const [f, ms] = await time(() => offBarcode('4600605029343'));
      return f ? { status: 'ok', detail: `${f.name} (${f.brand}) ${f.kcal} ккал/100 г, ${ms} мс` } : { status: 'fail', detail: 'продукт по тестовому штрихкоду не получен — нет интернета или база недоступна' };
    });
    await check('Разбор текста «словами» (встроенный)', async () => {
      const rows = parseText('200 г гречки, 2 яйца и кофе с молоком', SEED_FOODS);
      const txt = rows.map(r => `${r.food?.name} ${r.grams} г`).join('; ');
      return { status: rows.length === 3 ? 'ok' : 'warn', detail: txt || 'ничего не распознано' };
    });
    await check('Камера', async () => { const p = await Camera.getCameraPermissionsAsync(); return { status: p.granted ? 'ok' : 'warn', detail: p.granted ? 'доступ выдан' : 'доступ не выдан — выдастся при первом открытии сканера' }; });
    await check('AI-модель', async () => {
      if (!llmConfigured()) return { status: 'skip', detail: 'не подключена (Профиль → AI-тренер). Это нормально для первого теста.' };
      const [items, ms] = await time(() => llmParse('на завтрак две сосиски и 200 г гречки'));
      const [a, ms2] = await time(() => callLlm([{ role: 'user', content: 'Дай один короткий совет по питанию на вечер.' }], 0.4));
      return { status: items.length ? 'ok' : 'warn', detail: `разбор: ${items.map(i => `${i.name} ${i.grams} г${i.assumed ? ' (оценка)' : ''}`).join('; ')} [${ms} мс]; ответ тренера: «${a.slice(0, 120)}» [${ms2} мс]` };
    });
    await check('Свой сервер', async () => {
      if (!serverConfigured()) return { status: 'skip', detail: 'не используется' };
      const r = await fetch(st.settings.serverUrl.replace(/\/$/, '') + '/health'); return { status: r.ok ? 'ok' : 'fail', detail: 'HTTP ' + r.status + (st.token ? ', вход выполнен' : ', вход не выполнен') };
    });
    if (Platform.OS === 'android') {
      await check('Samsung Health / Health Connect', async () => {
        if (!st.settings.hcEnabled) return { status: 'skip', detail: 'не подключено (Профиль → Samsung Health → Подключить)' };
        const d = await healthDiagnostics(); return { status: d.ok ? 'ok' : 'warn', detail: d.lines.join('\n') };
      });
    }
    setBusy(false); setDone(true);
  };

  const buildReport = () => {
    const now = new Date(); const days = Array.from({ length: 14 }, (_, i) => addDays(today(), -i));
    const L: string[] = [];
    L.push('# ОТЧЁТ Nutri', `Дата: ${now.toLocaleString('ru-RU')}`, '');
    L.push('## Автопроверка', ...(res.length ? res.map(r => `${ICON[r.status]} ${r.name}: ${r.detail}`) : ['(не запускалась)']), '');
    L.push('## Ручной чек-лист', ...MANUAL.map((m, i) => `${manual[i] === 'ok' ? '👍' : manual[i] === 'bad' ? '👎' : '❔'} ${m}${notes[i] ? ' — ' + notes[i] : ''}`), '');
    L.push('## Что не понравилось / чего не хватает', free || '(пусто)', '');
    L.push('## Настройки (без ключей и паролей)',
      `Samsung Health: ${st.settings.hcEnabled ? 'подключён' : 'нет'}, прибавка активных ккал: ${st.settings.eatBack}%, запись веса/еды: ${st.settings.hcWriteWeight}/${st.settings.hcWriteNutrition}`,
      `AI: ${llmConfigured() ? `${st.settings.llmPreset} / ${st.settings.llmModel}` : 'не подключён'}; сервер: ${serverConfigured() ? 'да' : 'нет'}; соцсеть: ${st.settings.social}; тема: ${st.settings.theme}`,
      `Тело: замеров ${Object.keys(st.measures ?? {}).length}, записей состава ${Object.keys(st.bodycomp ?? {}).length}, анализов ${Object.keys(st.labs ?? {}).length}, способ расчёта нормы: ${st.settings.normMode ?? 'auto'}`,
      `Профиль: цель ${st.profile.goal}, вес ${st.profile.weight} → ${st.profile.goalWeight}`, '');
    L.push('## Дневник за 14 дней (записей / ккал)', ...days.map(d => { const es = entriesOn(st.entries, d); return `${d}: ${es.length} / ${Math.round(sum(es).kcal)}${st.health[d] ? `; шагов ${st.health[d].steps}, активных ккал ${st.health[d].activeKcal}` : ''}`; }), `Серия: ${streak(st.entries)}`, '');
    const last = Object.values(st.entries).sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 15);
    L.push('## Последние записи', ...last.map(e => `${e.date} ${e.meal}: ${e.name} ${e.grams} г = ${e.kcal} ккал`), '');
    const log = getLog().slice(-40);
    L.push('## Журнал ошибок', ...(log.length ? log.map(x => `${new Date(x.t).toLocaleTimeString('ru-RU')} [${x.kind}] ${x.msg}`) : ['(пусто)']));
    return L.join('\n');
  };

  const sendFile = async () => {
    const text = buildReport();
    try {
      const name = `nutri-report-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}.txt`;
      const f = new File(Paths.cache, name); f.create({ overwrite: true }); f.write(text);
      if (await Sharing.isAvailableAsync()) { await Sharing.shareAsync(f.uri, { mimeType: 'text/plain', dialogTitle: 'Отправить отчёт' }); return; }
    } catch {}
    await Share.share({ message: text });
  };
  const copy = async () => { await Clipboard.setStringAsync(buildReport()); Alert.alert('Скопировано', 'Теперь вставьте отчёт в чат с разработчиком.'); };

  return (
    <Screen>
      <Txt size={13} muted style={{ marginBottom: 12 }}>Шаг 1 — нажмите «Запустить автопроверку». Шаг 2 — отметьте ручной чек-лист (после того как попробуете функции). Шаг 3 — «Отправить отчёт».</Txt>

      <Card>
        <Txt bold size={17} style={{ marginBottom: 8 }}>1. Автопроверка</Txt>
        <Btn title={busy ? 'Проверяю…' : 'Запустить автопроверку'} onPress={run} disabled={busy} />
        {busy && <ActivityIndicator style={{ marginTop: 10 }} />}
        {res.map(r => (
          <View key={r.name} style={{ marginTop: 12 }}>
            <Txt bold>{ICON[r.status]} {r.name}</Txt>
            <Txt size={12.5} muted>{r.detail}</Txt>
          </View>
        ))}
        {done && <Txt size={12.5} color={t.acc} style={{ marginTop: 12 }}>Готово. ⚠️ и ❌ — это нормально, их я разберу по отчёту.</Txt>}
      </Card>

      <Card>
        <Txt bold size={17} style={{ marginBottom: 4 }}>2. Ваши впечатления</Txt>
        <Txt size={12.5} muted style={{ marginBottom: 6 }}>Нажмите 👍 или 👎. Если 👎 — коротко напишите, что не так.</Txt>
        {MANUAL.map((m, i) => (
          <View key={i} style={{ paddingVertical: 10, borderTopWidth: 1, borderTopColor: t.line }}>
            <Txt size={14}>{i + 1}. {m}</Txt>
            <View style={[s.row, { marginTop: 8 }]}>
              <Chip label="👍 Да" on={manual[i] === 'ok'} onPress={() => setManual(x => ({ ...x, [i]: 'ok' }))} />
              <Chip label="👎 Нет" on={manual[i] === 'bad'} onPress={() => setManual(x => ({ ...x, [i]: 'bad' }))} />
            </View>
            <View style={{ marginTop: 6 }}><Input placeholder="Комментарий (необязательно)" value={notes[i] ?? ''} onChangeText={v => setNotes(x => ({ ...x, [i]: v }))} /></View>
          </View>
        ))}
        <View style={{ marginTop: 10 }}><Input label="Что бесило или чего не хватает?" multiline value={free} onChangeText={setFree} style={{ minHeight: 80, textAlignVertical: 'top' }} /></View>
      </Card>

      <Card>
        <Txt bold size={17} style={{ marginBottom: 8 }}>3. Отправить отчёт</Txt>
        <Btn title="📤 Отправить файлом (почта, Диск…)" onPress={sendFile} />
        <Btn kind="ghost" style={{ marginTop: 10 }} title="📋 Скопировать текст отчёта" onPress={copy} />
        <Txt size={12} muted style={{ marginTop: 8 }}>В отчёте нет паролей и API-ключей. Есть: результаты проверок, ваши записи питания за 14 дней и журнал ошибок.</Txt>
        <Btn kind="ghost" style={{ marginTop: 10 }} title="Очистить журнал ошибок" onPress={() => { clearLog(); Alert.alert('Журнал очищен'); }} />
      </Card>
    </Screen>
  );
}
