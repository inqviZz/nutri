import React, { useMemo, useState } from 'react';
import { Alert, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen } from '../components/Screen';
import { Btn, Card, Chip, Input, Txt, s, useTheme } from '../ui';
import { useStore, useTargets } from '../store';
import { dateLabel, fmt, today } from '../core/nutrition';
import { labFlag, sanitizeComp } from '../core/body';
import type { BodyComp } from '../core/types';
import { refreshHealth } from '../healthSync';
import { connectHealth } from '../health';

const COMP_FIELDS: [keyof BodyComp, string][] = [['weightKg', 'Вес, кг'], ['fatPct', 'Жир, %'], ['muscleKg', 'Мышцы, кг'], ['waterPct', 'Вода, %'], ['visceral', 'Висцеральный жир'], ['bmr', 'Осн. обмен, ккал']];
const num = (v: string) => { const n = Number(v.replace(',', '.')); return v.trim() && Number.isFinite(n) ? n : undefined; };
const SRC = { manual: 'вручную', photo: 'по фото (AI)', health: 'Health Connect' } as const;

export default function Body() {
  const t = useTheme(); const r = useRouter();
  const T = useTargets();
  const comps = useStore(s => s.bodycomp); const labs = useStore(s => s.labs); const settings = useStore(s => s.settings);
  const [form, setForm] = useState(false); const [f, setF] = useState<Record<string, string>>({}); const [msg, setMsg] = useState('');
  const [lab, setLab] = useState(false); const [lf, setLf] = useState({ name: '', value: '', unit: '', lo: '', hi: '' });
  const list = useMemo(() => Object.values(comps).sort((a, b) => (a.date < b.date ? 1 : a.updatedAt < b.updatedAt ? 1 : -1)), [comps]);
  const labDays = useMemo(() => { const g: Record<string, typeof labs[string][]> = {}; Object.values(labs).forEach(l => { (g[l.date] ??= []).push(l); }); return Object.entries(g).sort((a, b) => (a[0] < b[0] ? 1 : -1)); }, [labs]);
  const b = T.basis; const mode = settings.normMode ?? 'auto';
  const set = (m: typeof mode) => useStore.getState().setSettings({ normMode: m });

  const saveComp = () => {
    const raw: Partial<BodyComp> = {}; COMP_FIELDS.forEach(([k]) => { const v = num(f[k] ?? ''); if (v != null) (raw as any)[k] = v; });
    const clean = sanitizeComp(raw);
    if (!Object.keys(clean).length) return Alert.alert('Введите хотя бы одно значение');
    const dropped = Object.keys(raw).filter(k => !(k in clean));
    if (dropped.length) return Alert.alert('Проверьте значения', 'Подозрительно для: ' + COMP_FIELDS.filter(([k]) => dropped.includes(k)).map(x => x[1]).join(', '));
    useStore.getState().addBodyComp({ date: today(), source: 'manual', ...clean }); setF({}); setForm(false); setMsg('Сохранено ✓ Норма пересчитана.');
  };
  const fromHealth = async () => {
    setMsg('Читаю Health Connect…');
    const res = await connectHealth({ writeWeight: settings.hcWriteWeight, writeNutrition: settings.hcWriteNutrition });
    if (!res.ok) return setMsg('Нет доступа к Health Connect. Профиль → Samsung Health → «Подключить» и разрешите чтение состава тела.');
    useStore.getState().setSettings({ hcEnabled: true });
    const before = Object.values(useStore.getState().bodycomp).filter(c => c.source === 'health').length;
    await refreshHealth();
    const after = Object.values(useStore.getState().bodycomp).filter(c => c.source === 'health').length;
    setMsg(after > before ? `Найдено записей: ${after - before} ✓` : after ? 'Новых записей нет.' : 'Состава тела в Health Connect не найдено. Его передают часы с БИА или умные весы через Samsung Health (Настройки → Health Connect). Либо введите значения вручную или по фото.');
  };
  const saveLab = () => {
    const v = num(lf.value); if (!lf.name.trim() || v == null) return Alert.alert('Введите название и значение');
    useStore.getState().addLabs([{ date: today(), name: lf.name.trim(), value: v, unit: lf.unit.trim(), refLow: num(lf.lo) ?? null, refHigh: num(lf.hi) ?? null }]);
    setLf({ name: '', value: '', unit: '', lo: '', hi: '' }); setLab(false);
  };

  const row = (label: string, val: React.ReactNode, active: boolean) => (
    <View style={[s.row, { justifyContent: 'space-between', paddingVertical: 7, borderTopWidth: 1, borderTopColor: t.line }]}><Txt bold={active} muted={!active} size={14}>{active ? '▶ ' : ''}{label}</Txt><Txt bold={active} muted={!active} size={14}>{val}</Txt></View>
  );
  const ad = b.methods.adaptive;

  return (
    <Screen edges={[]}>
      <Card>
        <Txt size={18} bold style={{ marginBottom: 4 }}>Ваша норма: {fmt(T.kcal)} ккал</Txt>
        <Txt muted size={13} style={{ marginBottom: 8 }}>Расход (без цели) ≈ {fmt(T.tdee)} ккал/день. {b.why}</Txt>
        {row('Общая формула', fmt(b.methods.mifflin) + ' ккал', b.mode === 'mifflin')}
        {row('По составу тела', b.methods.katch ? fmt(b.methods.katch) + ' ккал' : 'нужен % жира', b.mode === 'katch')}
        {row('По вашим данным', ad ? fmt(ad.tdee) + ' ккал' + (ad.confidence === 'low' ? ' (пока неточно)' : '') : 'нужно 10+ дней дневника и 4+ взвешивания за 4 недели', b.mode === 'adaptive')}
        <Txt size={12} muted style={{ marginTop: 8, marginBottom: 6 }}>Способ расчёта:</Txt>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {([['auto', 'Авто'], ['mifflin', 'Формула'], ['katch', 'Состав тела'], ['adaptive', 'По моим данным']] as const).map(([k, l]) => <Chip key={k} label={l} on={mode === k} onPress={() => set(k)} />)}
        </View>
        {T.limited && <Txt size={12.5} color={t.warn} style={{ marginTop: 8 }}>⚠️ Норма поднята до безопасного минимума ({fmt(T.kcal)} ккал). Слишком большой дефицит вреден: при таких цифрах лучше обсудить план с врачом или диетологом.</Txt>}
        {T.minor && <Txt size={12.5} color={t.warn} style={{ marginTop: 8 }}>ℹ️ Вам меньше 18 лет: приложение не задаёт дефицит калорий. Вопросы веса — к врачу.</Txt>}
        <Txt size={11.5} muted style={{ marginTop: 8 }}>Это ориентир, а не медицинская рекомендация. Реальный расход точнее всего показывает ваша собственная динамика веса при честном дневнике.</Txt>
      </Card>

      <Card>
        <Txt size={18} bold style={{ marginBottom: 8 }}>Состав тела</Txt>
        {list[0] ? (
          <View style={{ marginBottom: 8 }}>
            <Txt muted size={12.5}>{dateLabel(list[0].date)} · {SRC[list[0].source]}</Txt>
            <Txt size={15}>{COMP_FIELDS.concat([['leanKg', 'Безжировая, кг']]).filter(([k]) => list[0][k] != null).map(([k, l]) => `${l}: ${String(list[0][k]).replace('.', ',')}`).join(' · ')}</Txt>
          </View>
        ) : <Txt muted style={{ marginBottom: 8 }}>Пока нет данных. Добавьте результат БИА (часы, весы, клиники), и норма калорий станет точнее.</Txt>}
        <View style={{ gap: 8 }}>
          <Btn kind="ai" title="📷 Распознать по фото (AI)" onPress={() => r.push('/labscan')} />
          <Btn kind="ghost" title="✍️ Ввести вручную" onPress={() => setForm(x => !x)} />
          <Btn kind="ghost" title="⟳ Взять из Health Connect" onPress={fromHealth} />
        </View>
        {msg ? <Txt size={13} muted style={{ marginTop: 8 }}>{msg}</Txt> : null}
        {form && (
          <View style={{ marginTop: 12 }}>
            {[0, 2, 4].map(i => <View key={i} style={[s.row, { gap: 10, marginBottom: 10 }]}>{COMP_FIELDS.slice(i, i + 2).map(([k, l]) => <Input key={k} label={l} keyboardType="decimal-pad" value={f[k] ?? ''} onChangeText={v => setF(x => ({ ...x, [k]: v }))} />)}</View>)}
            <Btn title="Сохранить" onPress={saveComp} />
          </View>
        )}
      </Card>

      {list.length > 0 && (
        <Card>
          <Txt size={17} bold style={{ marginBottom: 6 }}>История состава тела</Txt>
          {list.slice(0, 20).map(c => (
            <View key={c.id} style={{ paddingVertical: 8, borderTopWidth: 1, borderTopColor: t.line }}>
              <View style={[s.row, { justifyContent: 'space-between' }]}><Txt bold>{dateLabel(c.date)}</Txt><Btn small kind="ghost" title="Удалить" onPress={() => useStore.getState().removeBodyComp(c.id)} /></View>
              <Txt size={13} muted>{SRC[c.source]} · {COMP_FIELDS.filter(([k]) => c[k] != null).map(([k, l]) => `${l.split(',')[0]} ${c[k]}`).join(' · ')}</Txt>
            </View>
          ))}
        </Card>
      )}

      <Card>
        <Txt size={18} bold style={{ marginBottom: 4 }}>Анализы</Txt>
        <Txt size={12.5} muted style={{ marginBottom: 8 }}>Хранятся только на этом телефоне. Приложение показывает, попадает ли значение в границы, напечатанные в бланке, но не ставит диагнозов и не назначает лечение — с результатами идите к врачу.</Txt>
        {labDays.length === 0 && <Txt muted style={{ marginBottom: 8 }}>Пока ничего нет. Фото бланка можно распознать кнопкой выше.</Txt>}
        {labDays.map(([d, items]) => (
          <View key={d} style={{ marginBottom: 8 }}>
            <Txt bold size={14}>{dateLabel(d)}</Txt>
            {items.map(l => { const fl = labFlag(l); const col = fl === 'ok' ? t.acc : fl === 'none' ? t.muted : t.warn; return (
              <View key={l.id} style={[s.row, { justifyContent: 'space-between', paddingVertical: 6, borderTopWidth: 1, borderTopColor: t.line, gap: 8 }]}>
                <View style={{ flex: 1 }}><Txt size={14}>{l.name}</Txt><Txt size={12} muted>норма по бланку: {l.refLow != null || l.refHigh != null ? `${l.refLow ?? '…'} – ${l.refHigh ?? '…'}` : 'не указана'}</Txt></View>
                <Txt bold color={col}>{String(l.value).replace('.', ',')} {l.unit} {fl === 'low' ? '↓' : fl === 'high' ? '↑' : fl === 'ok' ? '✓' : ''}</Txt>
                <Btn small kind="ghost" title="✕" onPress={() => useStore.getState().removeLab(l.id)} />
              </View>); })}
          </View>
        ))}
        <Btn small kind="ghost" title={lab ? 'Скрыть форму' : '+ Добавить показатель'} onPress={() => setLab(x => !x)} />
        {lab && (
          <View style={{ marginTop: 10 }}>
            <Input label="Показатель" value={lf.name} onChangeText={v => setLf(x => ({ ...x, name: v }))} placeholder="Например, Глюкоза" />
            <View style={[s.row, { gap: 10, marginTop: 10 }]}><Input label="Значение" keyboardType="decimal-pad" value={lf.value} onChangeText={v => setLf(x => ({ ...x, value: v }))} /><Input label="Единицы" value={lf.unit} onChangeText={v => setLf(x => ({ ...x, unit: v }))} placeholder="ммоль/л" /></View>
            <View style={[s.row, { gap: 10, marginTop: 10, marginBottom: 10 }]}><Input label="Норма от" keyboardType="decimal-pad" value={lf.lo} onChangeText={v => setLf(x => ({ ...x, lo: v }))} /><Input label="Норма до" keyboardType="decimal-pad" value={lf.hi} onChangeText={v => setLf(x => ({ ...x, hi: v }))} /></View>
            <Btn title="Сохранить показатель" onPress={saveLab} />
          </View>
        )}
      </Card>
    </Screen>
  );
}
