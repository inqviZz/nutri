import React, { useState } from 'react';
import { View, Alert } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Screen } from '../components/Screen';
import { Btn, Input, Txt, s } from '../ui';
import { useStore } from '../store';
import { uid } from '../core/nutrition';
import type { Food } from '../core/types';
import { publishFood } from '../api';

export default function Custom() {
  const r = useRouter();
  const { barcode, meal = 'b', date } = useLocalSearchParams<{ barcode?: string; meal?: string; date?: string }>();
  const [f, setF] = useState({ name: '', kcal: '', p: '0', f: '0', c: '0', port: '100' });
  const up = (k: keyof typeof f) => (v: string) => setF(x => ({ ...x, [k]: v }));
  const n = (v: string) => Number(v.replace(',', '.')) || 0;

  const save = () => {
    const kcal = n(f.kcal), p = n(f.p), fat = n(f.f), c = n(f.c);
    if (!f.name.trim() || !kcal) return Alert.alert('Заполните название и калории на 100 г');
    if (kcal > 900 || p + fat + c > 100) return Alert.alert('Проверьте значения: на 100 г не может быть больше 100 г БЖУ и 900 ккал.');
    const diff = Math.abs(4 * p + 9 * fat + 4 * c - kcal) / Math.max(kcal, 50);
    const food: Food = { id: 'user:' + (barcode ?? uid()), name: f.name.trim(), barcode: barcode ?? null, kcal, protein: p, fat, carbs: c, portionG: n(f.port) || 100, unit: 'порция', source: 'user', quality: diff <= 0.3 ? 1 : 0.7 };
    const go = () => { useStore.getState().saveCustomFood(food); publishFood(food); r.replace({ pathname: '/portion', params: { foodId: food.id, meal, date } }); };
    if (diff > 0.3) Alert.alert('Калории не сходятся с БЖУ', `По формуле 4·Б + 9·Ж + 4·У получается ≈ ${Math.round(4 * p + 9 * fat + 4 * c)} ккал. Сохранить как есть?`, [{ text: 'Исправить' }, { text: 'Сохранить', onPress: go }]);
    else go();
  };

  return (
    <Screen>
      {barcode ? <Txt muted style={{ marginBottom: 10 }}>Штрихкод: {barcode}</Txt> : null}
      <Input label="Название" value={f.name} onChangeText={up('name')} placeholder="Например, Сырники домашние" />
      <View style={[s.row, { gap: 10, marginTop: 12 }]}><Input label="Ккал / 100 г" keyboardType="decimal-pad" value={f.kcal} onChangeText={up('kcal')} /><Input label="Порция, г" keyboardType="decimal-pad" value={f.port} onChangeText={up('port')} /></View>
      <View style={[s.row, { gap: 10, marginTop: 12 }]}><Input label="Белки" keyboardType="decimal-pad" value={f.p} onChangeText={up('p')} /><Input label="Жиры" keyboardType="decimal-pad" value={f.f} onChangeText={up('f')} /><Input label="Углеводы" keyboardType="decimal-pad" value={f.c} onChangeText={up('c')} /></View>
      <Btn style={{ marginTop: 20 }} title="Сохранить и выбрать порцию" onPress={save} />
    </Screen>
  );
}
