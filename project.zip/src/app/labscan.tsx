import React, { useState } from 'react';
import { ActivityIndicator, Alert, Image, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Screen } from '../components/Screen';
import { Btn, Card, Input, Txt, s, useTheme } from '../ui';
import { useStore } from '../store';
import { llmConfigured } from '../llm';
import { pickDocPhoto, recognizeDocument, type DocResult, type LabRow } from '../labs';
import type { BodyComp } from '../core/types';
import { sanitizeComp } from '../core/body';
import { today } from '../core/nutrition';

const FIELDS: [keyof BodyComp, string][] = [['weightKg', 'Вес, кг'], ['fatPct', 'Жир, %'], ['muscleKg', 'Мышцы, кг'], ['leanKg', 'Безжировая масса, кг'], ['waterPct', 'Вода, %'], ['visceral', 'Висцеральный жир'], ['boneKg', 'Кости, кг'], ['bmr', 'Осн. обмен, ккал']];
const num = (v: string) => { const n = Number(v.replace(',', '.')); return v.trim() && Number.isFinite(n) ? n : undefined; };
type Row = { name: string; value: string; unit: string; lo: string; hi: string };

export default function LabScan() {
  const t = useTheme(); const r = useRouter();
  const settings = useStore(s => s.settings);
  const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [uri, setUri] = useState('');
  const [res, setRes] = useState<DocResult | null>(null);
  const [date, setDate] = useState(today()); const [cf, setCf] = useState<Record<string, string>>({}); const [rows, setRows] = useState<Row[]>([]);
  const host = (() => { try { return new URL(settings.llmUrl ?? '').host; } catch { return 'AI-модель'; } })();

  const go = async (source: 'camera' | 'library') => {
    setErr('');
    if (!llmConfigured()) return setErr('Сначала подключите AI: Профиль → «✨ AI-тренер». Для чтения картинок нужна модель с поддержкой изображений (например, Claude через RouterAI). DeepSeek картинки не читает.');
    if (!settings.visionConsent) {
      const ok = await new Promise<boolean>(res => Alert.alert('Отправить фото в AI?', `Снимок будет отправлен на сервер ${host}, а оттуда, возможно, зарубежному провайдеру модели. Это медицинские данные. Закройте ФИО, дату рождения и номер полиса, если они есть на бланке. Хранить фото приложение не будет.`, [{ text: 'Отмена', style: 'cancel', onPress: () => res(false) }, { text: 'Согласен', onPress: () => res(true) }]));
      if (!ok) return; useStore.getState().setSettings({ visionConsent: true });
    }
    try {
      const p = await pickDocPhoto(source); if (!p) return;
      setUri(p.uri); setBusy(true);
      const d = await recognizeDocument(p.b64);
      setRes(d); setDate(d.date);
      const o: Record<string, string> = {}; FIELDS.forEach(([k]) => { const v = d.comp[k]; if (v != null) o[k] = String(v); }); setCf(o);
      setRows(d.labs.map(l => ({ name: l.name, value: String(l.value), unit: l.unit, lo: l.refLow == null ? '' : String(l.refLow), hi: l.refHigh == null ? '' : String(l.refHigh) })));
    } catch (e: any) { setErr(String(e?.message ?? e)); }
    setBusy(false);
  };

  const save = () => {
    const raw: Partial<BodyComp> = {}; FIELDS.forEach(([k]) => { const v = num(cf[k] ?? ''); if (v != null) (raw as any)[k] = v; });
    const clean = sanitizeComp(raw);
    const bad = Object.keys(raw).filter(k => !(k in clean));
    if (bad.length) return Alert.alert('Проверьте значения', 'Подозрительно для: ' + FIELDS.filter(([k]) => bad.includes(k)).map(x => x[1]).join(', '));
    const labs: Omit<LabRowSave, never>[] = [];
    for (const x of rows) { const v = num(x.value); if (!x.name.trim() || v == null) continue; labs.push({ date, name: x.name.trim(), value: v, unit: x.unit.trim(), refLow: num(x.lo) ?? null, refHigh: num(x.hi) ?? null }); }
    if (!Object.keys(clean).length && !labs.length) return Alert.alert('Нечего сохранять');
    if (Object.keys(clean).length) useStore.getState().addBodyComp({ date, source: 'photo', ...clean });
    if (labs.length) useStore.getState().addLabs(labs);
    Alert.alert('Сохранено ✓', 'Данные в разделе «Состав тела и анализы».', [{ text: 'Ок', onPress: () => r.back() }]);
  };
  const upRow = (i: number, k: keyof Row, v: string) => setRows(x => x.map((y, j) => (j === i ? { ...y, [k]: v } : y)));

  return (
    <Screen edges={[]}>
      {!res && (
        <Card>
          <Txt size={18} bold style={{ marginBottom: 6 }}>Фото анализов или БИА</Txt>
          <Txt muted size={13.5} style={{ marginBottom: 12 }}>Сфотографируйте бланк или распечатку анализатора состава тела (InBody, Tanita, весы, часы) — приложение само заполнит поля. Снимайте ровно, при хорошем свете, чтобы цифры читались. Перед сохранением вы проверите каждое значение.</Txt>
          <View style={{ gap: 8 }}>
            <Btn kind="ai" title="📷 Сфотографировать" onPress={() => go('camera')} disabled={busy} />
            <Btn kind="ghost" title="🖼 Выбрать из галереи" onPress={() => go('library')} disabled={busy} />
          </View>
          {busy && <View style={{ alignItems: 'center', marginTop: 16 }}><ActivityIndicator /><Txt muted size={13} style={{ marginTop: 6 }}>Распознаю… до минуты</Txt></View>}
          {err ? <Txt color={t.danger} size={13.5} style={{ marginTop: 12 }}>{err}</Txt> : null}
          <Txt size={11.5} muted style={{ marginTop: 12 }}>Фото отправляется в выбранную вами AI-модель ({host}) и в приложении не сохраняется.</Txt>
        </Card>
      )}
      {res && (
        <>
          <Card style={{ backgroundColor: t.warnSoft }}>
            <Txt bold color={t.warn}>Проверьте каждое число по бланку</Txt>
            <Txt size={13} color={t.warn}>AI мог ошибиться: перепутать запятую, потерять цифру или строку. Исправьте поля, лишнее удалите.</Txt>
          </Card>
          {uri ? <Image source={{ uri }} style={{ width: '100%', height: 160, borderRadius: 16, marginBottom: 14 }} resizeMode="cover" /> : null}
          {res.kind === 'unknown' && <Card><Txt>На фото не нашлось ни состава тела, ни анализов. Попробуйте снять ближе и ровнее.</Txt><Btn small kind="ghost" style={{ marginTop: 8 }} title="Снять заново" onPress={() => { setRes(null); setUri(''); }} /></Card>}
          <Card>
            <Input label="Дата (ГГГГ-ММ-ДД)" value={date} onChangeText={setDate} />
          </Card>
          {Object.keys(cf).length > 0 && (
            <Card>
              <Txt size={17} bold style={{ marginBottom: 8 }}>Состав тела</Txt>
              {FIELDS.filter(([k]) => cf[k] != null).map(([k, l]) => <View key={k} style={{ marginBottom: 8 }}><Input label={l} keyboardType="decimal-pad" value={cf[k]} onChangeText={v => setCf(x => ({ ...x, [k]: v }))} /></View>)}
            </Card>
          )}
          {rows.length > 0 && (
            <Card>
              <Txt size={17} bold style={{ marginBottom: 8 }}>Анализы ({rows.length})</Txt>
              {rows.map((x, i) => (
                <View key={i} style={{ paddingVertical: 10, borderTopWidth: 1, borderTopColor: t.line }}>
                  <View style={[s.row, { gap: 8 }]}><Input value={x.name} onChangeText={v => upRow(i, 'name', v)} /><Btn small kind="ghost" title="✕" onPress={() => setRows(a => a.filter((_, j) => j !== i))} /></View>
                  <View style={[s.row, { gap: 8, marginTop: 8 }]}>
                    <Input label="Значение" keyboardType="decimal-pad" value={x.value} onChangeText={v => upRow(i, 'value', v)} />
                    <Input label="Ед." value={x.unit} onChangeText={v => upRow(i, 'unit', v)} />
                    <Input label="Норма от" keyboardType="decimal-pad" value={x.lo} onChangeText={v => upRow(i, 'lo', v)} />
                    <Input label="до" keyboardType="decimal-pad" value={x.hi} onChangeText={v => upRow(i, 'hi', v)} />
                  </View>
                </View>
              ))}
            </Card>
          )}
          {res.kind !== 'unknown' && <Btn title="Сохранить" onPress={save} />}
        </>
      )}
    </Screen>
  );
}
type LabRowSave = { date: string; name: string; value: number; unit: string; refLow: number | null; refHigh: number | null };
