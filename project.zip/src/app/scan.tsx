import React, { useRef, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Btn, Input, Txt, useTheme } from '../ui';
import { lookupBarcode } from '../api';

export default function Scan() {
  const r = useRouter(); const t = useTheme();
  const { meal = 'b', date } = useLocalSearchParams<{ meal?: string; date?: string }>();
  const [perm, ask] = useCameraPermissions();
  const [state, setState] = useState<'scan' | 'loading' | 'notfound'>('scan');
  const [code, setCode] = useState(''); const [manual, setManual] = useState('');
  const busy = useRef(false);

  const handle = async (c: string) => {
    if (busy.current) return; busy.current = true; setCode(c); setState('loading');
    const f = await lookupBarcode(c);
    if (f) r.replace({ pathname: '/portion', params: { foodId: f.id, meal, date } });
    else { setState('notfound'); busy.current = false; }
  };

  if (!perm) return <View style={{ flex: 1, backgroundColor: t.bg }} />;
  if (!perm.granted) return (
    <View style={{ flex: 1, backgroundColor: t.bg, padding: 24, justifyContent: 'center', gap: 14 }}>
      <Txt size={40} style={{ textAlign: 'center' }}>📷</Txt>
      <Txt style={{ textAlign: 'center' }}>Камера нужна только для сканирования штрихкодов. Фото не сохраняются и никуда не отправляются.</Txt>
      <Btn title="Разрешить камеру" onPress={ask} />
      <Input placeholder="…или введите штрихкод цифрами" keyboardType="number-pad" value={manual} onChangeText={setManual} onSubmitEditing={() => handle(manual.trim())} />
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      {state === 'scan' && (
        <CameraView style={{ flex: 1 }} facing="back"
          barcodeScannerSettings={{ barcodeTypes: ['ean13', 'ean8', 'upc_a', 'upc_e'] }}
          onBarcodeScanned={({ data }) => handle(data)} />
      )}
      {state === 'scan' && (
        <View pointerEvents="none" style={{ position: 'absolute', top: '30%', left: '12%', right: '12%', height: 160, borderWidth: 3, borderColor: '#fff', borderRadius: 18, opacity: 0.85 }} />
      )}
      {state === 'scan' && <View style={{ position: 'absolute', bottom: 40, left: 20, right: 20 }}><Txt color="#fff" style={{ textAlign: 'center' }}>Наведите камеру на штрихкод упаковки</Txt></View>}
      {state === 'loading' && <View style={{ flex: 1, justifyContent: 'center' }}><ActivityIndicator color="#fff" size="large" /><Txt color="#fff" style={{ textAlign: 'center', marginTop: 12 }}>Ищу {code}…</Txt></View>}
      {state === 'notfound' && (
        <View style={{ flex: 1, backgroundColor: t.bg, padding: 24, justifyContent: 'center', gap: 12 }}>
          <Txt size={40} style={{ textAlign: 'center' }}>🤷</Txt>
          <Txt bold size={18} style={{ textAlign: 'center' }}>Продукта {code} нет в базе</Txt>
          <Txt muted style={{ textAlign: 'center' }}>Введите данные с упаковки один раз — они сохранятся для вас (и для всех, если подключён сервер).</Txt>
          <Btn title="Добавить по упаковке" onPress={() => r.replace({ pathname: '/custom', params: { barcode: code, meal, date } })} />
          <Btn kind="ghost" title="Сканировать снова" onPress={() => { setState('scan'); }} />
        </View>
      )}
    </View>
  );
}
