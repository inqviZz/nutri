import React, { useEffect, useState } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { useStore } from '../store';
import { useTheme } from '../ui';
import { installCrashLogger, loadLog } from '../diag';

installCrashLogger();

export default function Root() {
  const [ready, setReady] = useState(useStore.persist.hasHydrated());
  useEffect(() => { const u = useStore.persist.onFinishHydration(() => setReady(true)); if (useStore.persist.hasHydrated()) setReady(true); return u; }, []);
  useEffect(() => { loadLog(); }, []);
  const t = useTheme();
  if (!ready) return <View style={{ flex: 1, justifyContent: 'center', backgroundColor: t.bg }}><ActivityIndicator /></View>;
  const modal = (title: string) => ({ presentation: 'modal' as const, title, headerStyle: { backgroundColor: t.card }, headerTintColor: t.text });
  return (
    <SafeAreaProvider>
      <StatusBar style={t.dark ? 'light' : 'dark'} />
      <Stack screenOptions={{ contentStyle: { backgroundColor: t.bg } }}>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="add" options={modal('Добавить еду')} />
        <Stack.Screen name="scan" options={modal('Штрихкод')} />
        <Stack.Screen name="portion" options={modal('Порция')} />
        <Stack.Screen name="aitext" options={modal('AI: опишите словами')} />
        <Stack.Screen name="custom" options={modal('Свой продукт')} />
        <Stack.Screen name="measures" options={modal('Замеры тела')} />
        <Stack.Screen name="body" options={modal('Состав тела и норма')} />
        <Stack.Screen name="labscan" options={modal('Фото анализов')} />
        <Stack.Screen name="diagnostics" options={modal('Проверка и отчёт')} />
      </Stack>
    </SafeAreaProvider>
  );
}
