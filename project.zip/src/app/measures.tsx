import React, { useEffect, useMemo, useState } from 'react';
import { Alert, View } from 'react-native';
import Svg, { Circle, Path, Text as SvgText } from 'react-native-svg';
import { Screen } from '../components/Screen';
import { Btn, Card, Chip, Input, Txt, s, useTheme } from '../ui';
import { useStore } from '../store';
import { addDays, dateLabel, today } from '../core/nutrition';
import { MEASURE_FIELDS, navyFat, whtr, whtrLabel } from '../core/body';
import type { Measure } from '../core/types';

type K = keyof Omit<Measure, 'updatedAt'>;
const num = (v: string) => { const n = Number(v.replace(',', '.')); return v.trim() && Number.isFinite(n) ? n : undefined; };

function Chart({ pts, color }: { pts: { d: string; v: number }[]; color: string }) {
  const t = useTheme(); const W = 320, H = 110;
  if (pts.length < 2) return <Txt muted size={13}>Для графика нужно хотя бы два замера этого обхвата.</Txt>;
  const mn = Math.min(...pts.map(p => p.v)) - 1, mx = Math.max(...pts.map(p => p.v)) + 1;
  const xy = pts.map((p, i) => [(i / (pts.length - 1)) * (W - 20) + 10, H - 16 - ((p.v - mn) / (mx - mn)) * (H - 36)]);
  const d = xy.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
  return (
    <Svg viewBox={`0 0 ${W} ${H}`} width="100%" height={130}>
      <Path d={d} stroke={color} strokeWidth={3} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      {xy.map((p, i) => <Circle key={i} cx={p[0]} cy={p[1]} r={4} fill={t.card} stroke={color} strokeWidth={2.5} />)}
      <SvgText x={xy[0][0]} y={H - 2} fontSize={10} fill={t.muted} textAnchor="start">{pts[0].v}</SvgText>
      <SvgText x={xy[xy.length - 1][0]} y={H - 2} fontSize={10} fill={t.muted} textAnchor="end">{pts[pts.length - 1].v}</SvgText>
    </Svg>
  );
}

export default function Measures() {
  const t = useTheme();
  const measures = useStore(s => s.measures); const profile = useStore(s => s.profile);
  const [date, setDate] = useState(today());
  const [f, setF] = useState<Record<string, string>>({});
  const [metric, setMetric] = useState<K>('waist');
  useEffect(() => { const m = measures[date]; const o: Record<string, string> = {}; MEASURE_FIELDS.forEach(([k]) => { if (m?.[k]) o[k] = String(m[k]); }); setF(o); }, [date]);

  const save = () => {
    const patch: Partial<Record<K, number>> = {};
    for (const [k, label] of MEASURE_FIELDS) {
      const v = num(f[k] ?? ''); if (v == null) continue;
      if (v < 10 || v > 250) return Alert.alert('Проверьте значение', `«${label}»: ${v} см — похоже на опечатку.`);
      patch[k] = v;
    }
    if (!Object.keys(patch).length) return Alert.alert('Введите хотя бы один обхват');
    useStore.getState().saveMeasure(date, patch); Alert.alert('Замеры сохранены ✓');
  };

  const rows = useMemo(() => Object.entries(measures).sort((a, b) => (a[0] < b[0] ? 1 : -1)), [measures]);
  const asc = [...rows].reverse();
  const series = asc.filter(([, m]) => m[metric]).map(([d, m]) => ({ d, v: m[metric] as number }));
  const last = (k: K) => asc.slice().reverse().find(([, m]) => m[k])?.[1][k];
  const waist = num(f.waist ?? '') ?? last('waist'); const neck = num(f.neck ?? '') ?? last('neck'); const hips = num(f.hips ?? '') ?? last('hips');
  const ratio = waist ? whtr(waist, profile.height) : null;
  const fat = waist && neck ? navyFat(profile.sex, profile.height, waist, neck, hips) : null;
  const prev = (d: string, k: K) => { const i = asc.findIndex(([x]) => x === d); for (let j = i - 1; j >= 0; j--) if (asc[j][1][k]) return asc[j][1][k] as number; return null; };

  return (
    <Screen edges={[]}>
      <Card>
        <View style={[s.row, { justifyContent: 'space-between', marginBottom: 10 }]}>
          <Btn small kind="ghost" title="‹" onPress={() => setDate(addDays(date, -1))} />
          <Txt bold>{dateLabel(date)}</Txt>
          <Btn small kind="ghost" title="›" disabled={date >= today()} onPress={() => setDate(addDays(date, 1))} />
        </View>
        <Txt size={12.5} muted style={{ marginBottom: 8 }}>Измеряйте сантиметровой лентой утром натощак, всегда в одном месте. Все значения в сантиметрах; пустые поля можно пропустить.</Txt>
        {Array.from({ length: Math.ceil(MEASURE_FIELDS.length / 2) }, (_, i) => MEASURE_FIELDS.slice(i * 2, i * 2 + 2)).map((pair, i) => (
          <View key={i} style={[s.row, { gap: 10, marginBottom: 10 }]}>
            {pair.map(([k, label]) => <Input key={k} label={label + ', см'} keyboardType="decimal-pad" value={f[k] ?? ''} onChangeText={v => setF(x => ({ ...x, [k]: v }))} />)}
            {pair.length === 1 && <View style={{ flex: 1 }} />}
          </View>
        ))}
        <Btn title="Сохранить замеры" onPress={save} />
      </Card>

      {(ratio || fat) && (
        <Card>
          <Txt size={17} bold style={{ marginBottom: 6 }}>Что это значит</Txt>
          {ratio ? <Txt style={{ marginBottom: 6 }}>Талия / рост = <Txt bold>{ratio.toFixed(2).replace('.', ',')}</Txt> — {whtrLabel(ratio)}. Ориентир: ниже 0,5.</Txt> : null}
          {fat ? <Txt>Оценка жира по обхватам (метод ВМС США): <Txt bold>≈ {String(fat).replace('.', ',')}%</Txt>. Это грубая оценка, ±3–5 п.п. Точнее — БИА (раздел «Состав тела»).</Txt> : null}
          {!fat && waist ? <Txt size={12.5} muted>Для оценки процента жира нужна ещё шея{profile.sex === 'f' ? ' и бёдра' : ''}.</Txt> : null}
        </Card>
      )}

      <Card>
        <Txt size={17} bold style={{ marginBottom: 8 }}>Динамика</Txt>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 6 }}>{MEASURE_FIELDS.map(([k, label]) => <Chip key={k} label={label} on={metric === k} onPress={() => setMetric(k)} />)}</View>
        <Chart pts={series} color={t.acc} />
      </Card>

      <Card>
        <Txt size={17} bold style={{ marginBottom: 6 }}>История</Txt>
        {rows.length === 0 && <Txt muted>Пока нет замеров.</Txt>}
        {rows.map(([d, m]) => (
          <View key={d} style={{ paddingVertical: 10, borderTopWidth: 1, borderTopColor: t.line }}>
            <View style={[s.row, { justifyContent: 'space-between' }]}>
              <Txt bold>{dateLabel(d)}</Txt>
              <Btn small kind="ghost" title="Удалить" onPress={() => Alert.alert('Удалить замеры за этот день?', '', [{ text: 'Отмена' }, { text: 'Удалить', style: 'destructive', onPress: () => useStore.getState().removeMeasure(d) }])} />
            </View>
            <Txt size={13} muted>
              {MEASURE_FIELDS.filter(([k]) => m[k]).map(([k, label]) => { const p = prev(d, k); const dl = p != null ? Math.round(((m[k] as number) - p) * 10) / 10 : null; return `${label} ${m[k]}${dl ? ` (${dl > 0 ? '+' : ''}${dl})` : ''}`; }).join(' · ')}
            </Txt>
          </View>
        ))}
      </Card>
    </Screen>
  );
}
