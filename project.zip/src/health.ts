/**
 * Интеграция с Health Connect (Android). Samsung Health синхронизируется с Health Connect,
 * поэтому приложение получает шаги, активные калории и вес из Samsung Health (а с часов Galaxy Watch — через него же).
 *
 * На iOS/в вебе все функции — безопасные «заглушки».
 */
import { Platform } from 'react-native';
import Constants from 'expo-constants';
import type { Entry } from './core/types';
import { addDays, parseKey, today } from './core/nutrition';
import type { HealthDay } from './store';
import { logEvent } from './diag';

type HC = typeof import('react-native-health-connect');
let hc: HC | null = null;
const load = (): HC | null => {
  if (Platform.OS !== 'android') return null;
  if (!hc) { try { hc = require('react-native-health-connect'); } catch { hc = null; } }
  return hc;
};

export const healthSupported = () => Platform.OS === 'android';
const OWN_PACKAGE = (Constants.expoConfig?.android?.package as string | undefined) ?? 'com.nutri.app';

export type ConnectResult = { ok: true } | { ok: false; reason: 'unsupported' | 'unavailable' | 'update_required' | 'denied' | 'error'; message?: string };

const READS = ['Steps', 'ActiveCaloriesBurned', 'TotalCaloriesBurned', 'Weight', 'BodyFat', 'LeanBodyMass', 'BasalMetabolicRate'] as const;

export async function connectHealth(opts: { writeWeight: boolean; writeNutrition: boolean }): Promise<ConnectResult> {
  const m = load(); if (!m) return { ok: false, reason: 'unsupported' };
  try {
    const status = await m.getSdkStatus();
    if (status === m.SdkAvailabilityStatus.SDK_UNAVAILABLE) return { ok: false, reason: 'unavailable' };
    if (status === m.SdkAvailabilityStatus.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED) return { ok: false, reason: 'update_required' };
    await m.initialize();
    const perms: any[] = READS.map(recordType => ({ accessType: 'read', recordType }));
    if (opts.writeWeight) perms.push({ accessType: 'write', recordType: 'Weight' });
    if (opts.writeNutrition) perms.push({ accessType: 'write', recordType: 'Nutrition' });
    const granted = await m.requestPermission(perms);
    const ok = granted.some((g: any) => g.accessType === 'read' && (g.recordType === 'Steps' || g.recordType === 'ActiveCaloriesBurned'));
    return ok ? { ok: true } : { ok: false, reason: 'denied' };
  } catch (e: any) { logEvent('hc-connect', e); return { ok: false, reason: 'error', message: String(e?.message ?? e) }; }
}

export function openHealthSettings() { try { load()?.openHealthConnectSettings(); } catch {} }

const range = (key: string) => {
  const s = parseKey(key), e = parseKey(addDays(key, 1));
  return { operator: 'between' as const, startTime: s.toISOString(), endTime: (key === today() ? new Date() : e).toISOString() };
};

/** Шаги и активные ккал за дни. Aggregate сам убирает дубли между источниками (часы + телефон). */
export async function readActivity(keys: string[]): Promise<Record<string, HealthDay>> {
  const m = load(); const out: Record<string, HealthDay> = {};
  if (!m) return out;
  await m.initialize();
  for (const k of keys) {
    const timeRangeFilter = range(k);
    let steps = 0, activeKcal = 0;
    try { steps = (await m.aggregateRecord({ recordType: 'Steps', timeRangeFilter })).COUNT_TOTAL ?? 0; } catch (e) { logEvent('hc-steps', e); }
    try { activeKcal = (await m.aggregateRecord({ recordType: 'ActiveCaloriesBurned', timeRangeFilter })).ACTIVE_CALORIES_TOTAL?.inKilocalories ?? 0; } catch (e) { logEvent('hc-active', e); }
    out[k] = { steps: Math.round(steps), activeKcal: Math.round(activeKcal) };
  }
  return out;
}

/** Вес из других приложений (Samsung Health, умные весы). Собственные записи пропускаем, чтобы не было эхо. */
export async function readWeights(days = 60): Promise<{ date: string; kg: number }[]> {
  const m = load(); if (!m) return [];
  await m.initialize();
  const start = new Date(Date.now() - days * 864e5).toISOString();
  const res = await m.readRecords('Weight', { timeRangeFilter: { operator: 'after', startTime: start }, ascendingOrder: true, pageSize: 200 });
  const byDay = new Map<string, number>();
  for (const r of res.records as any[]) {
    if (r.metadata?.dataOrigin === OWN_PACKAGE) continue;
    const d = new Date(r.time); const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    byDay.set(k, r.weight.value * (r.weight.unit === 'grams' ? 0.001 : r.weight.unit === 'pounds' ? 0.4536 : r.weight.unit === 'ounces' ? 0.02835 : 1));
  }
  return [...byDay.entries()].map(([date, kg]) => ({ date, kg: Math.round(kg * 10) / 10 }));
}

const dayKey = (iso: string) => { const d = new Date(iso); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const toKg = (m: { value: number; unit: string }) => m.value * (m.unit === 'grams' ? 0.001 : m.unit === 'pounds' ? 0.4536 : m.unit === 'ounces' ? 0.02835 : 1);

/** Состав тела из Health Connect (Samsung Health, умные весы, часы с БИА): % жира, безжировая масса, основной обмен. По одной записи на день. */
export async function readBodyComp(days = 90): Promise<{ date: string; fatPct?: number; leanKg?: number; bmr?: number }[]> {
  const m = load(); if (!m) return [];
  await m.initialize();
  const start = new Date(Date.now() - days * 864e5).toISOString();
  const byDay = new Map<string, { date: string; fatPct?: number; leanKg?: number; bmr?: number }>();
  const get = (k: string) => { let v = byDay.get(k); if (!v) { v = { date: k }; byDay.set(k, v); } return v; };
  const read = async (type: 'BodyFat' | 'LeanBodyMass' | 'BasalMetabolicRate') => {
    try { return ((await m.readRecords(type, { timeRangeFilter: { operator: 'after', startTime: start }, ascendingOrder: true, pageSize: 200 })).records as any[]).filter(r => r.metadata?.dataOrigin !== OWN_PACKAGE); }
    catch (e) { logEvent('hc-read-' + type, e); return []; }
  };
  for (const r of await read('BodyFat')) get(dayKey(r.time)).fatPct = Math.round(r.percentage * 10) / 10;
  for (const r of await read('LeanBodyMass')) get(dayKey(r.time)).leanKg = Math.round(toKg(r.mass) * 10) / 10;
  for (const r of await read('BasalMetabolicRate')) { const v = r.basalMetabolicRate; get(dayKey(r.time)).bmr = Math.round(v.unit === 'kilocaloriesPerDay' ? v.value : v.unit === 'watts' ? v.value * 20.65 : v.value); }
  return [...byDay.values()];
}

export async function writeWeight(date: string, kg: number) {
  const m = load(); if (!m) return;
  try {
    await m.initialize();
    const t = date === today() ? new Date() : new Date(parseKey(date).getTime() + 8 * 36e5);
    await m.insertRecords([{ recordType: 'Weight', time: t.toISOString(), weight: { value: kg, unit: 'kilograms' },
      metadata: { clientRecordId: 'nutri-weight-' + date, clientRecordVersion: Date.now() } } as any]);
  } catch (e) { logEvent('hc-write-weight', e); }
}

const MEALTYPE: Record<string, number> = { b: 1, l: 2, d: 3, s: 4 };
/** Запись съеденного в Health Connect (clientRecordId делает вставку идемпотентной — повтор обновит, а не задублирует). */
export async function writeNutrition(e: Entry) {
  const m = load(); if (!m) return;
  try {
    await m.initialize();
    const start = new Date(e.updatedAt); const end = new Date(start.getTime() + 60_000);
    await m.insertRecords([{ recordType: 'Nutrition', startTime: start.toISOString(), endTime: end.toISOString(), name: e.name, mealType: MEALTYPE[e.meal] ?? 0,
      energy: { value: e.kcal, unit: 'kilocalories' }, protein: { value: e.protein, unit: 'grams' }, totalFat: { value: e.fat, unit: 'grams' }, totalCarbohydrate: { value: e.carbs, unit: 'grams' },
      metadata: { clientRecordId: 'nutri-entry-' + e.id, clientRecordVersion: e.updatedAt } } as any]);
  } catch (err) { logEvent('hc-write-nutrition', err); }
}
export async function deleteNutrition(entryId: string) {
  const m = load(); if (!m) return;
  try { await m.initialize(); await m.deleteRecordsByUuids('Nutrition', [], ['nutri-entry-' + entryId]); } catch {}
}

/** Подробная диагностика для отчёта: статус, выданные права, откуда приходят данные (виден ли Samsung Health). */
export async function healthDiagnostics(): Promise<{ lines: string[]; ok: boolean }> {
  const m = load(); const lines: string[] = [];
  if (!m) return { lines: ['Health Connect доступен только на Android'], ok: false };
  try {
    const st = await m.getSdkStatus();
    lines.push('Статус Health Connect: ' + ({ 1: 'не установлен/недоступен', 2: 'нужно обновить', 3: 'доступен' } as any)[st]);
    if (st !== m.SdkAvailabilityStatus.SDK_AVAILABLE) return { lines, ok: false };
    await m.initialize();
    const granted = await m.getGrantedPermissions();
    lines.push('Выданные разрешения: ' + (granted.map((g: any) => `${g.accessType}:${g.recordType}`).join(', ') || 'нет'));
    const since = new Date(Date.now() - 30 * 864e5).toISOString();
    const origins = new Set<string>(); const foreign: Record<string, number> = {};
    for (const type of ['Steps', 'Weight', 'BodyFat', 'LeanBodyMass', 'ActiveCaloriesBurned'] as const) {
      try {
        const res: any = await m.readRecords(type, { timeRangeFilter: { operator: 'after', startTime: since }, pageSize: 100 });
        const o = new Set<string>(res.records.map((r: any) => r.metadata?.dataOrigin).filter(Boolean));
        o.forEach(x => origins.add(x));
        foreign[type] = res.records.filter((r: any) => r.metadata?.dataOrigin !== OWN_PACKAGE).length;
        lines.push(`${type}: записей за 30 дней — ${res.records.length}, не от Nutri — ${foreign[type]}${o.size ? ' (источники: ' + [...o].join(', ') + ')' : ''}`);
      } catch (e: any) { lines.push(`${type}: ошибка чтения — ${String(e?.message ?? e).slice(0, 120)}`); }
    }
    const sh = [...origins].some(o => /shealth|samsung|sec\.android/i.test(o));
    lines.push(sh ? '✅ Данные Samsung Health в Health Connect найдены' : '⚠️ Ни одна запись не пришла из Samsung Health. Шаги, скорее всего, идут от датчика самого телефона. Чтобы вес и состав тела пришли из Samsung Health: Samsung Health → Настройки → Health Connect → включить передачу (Вес, Состав тела) и убедиться, что данные есть в самом Samsung Health.');
    return { lines, ok: sh };
  } catch (e: any) { logEvent('hc-diag', e); lines.push('Ошибка: ' + String(e?.message ?? e)); return { lines, ok: false }; }
}
