import React from 'react';
import { ScrollView, View, type ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTheme } from '../ui';

export function Screen({ children, scroll = true, style, edges = ['top'] }: { children?: React.ReactNode; scroll?: boolean; style?: ViewStyle; edges?: ('top' | 'bottom')[] }) {
  const t = useTheme();
  return (
    <SafeAreaView edges={edges} style={{ flex: 1, backgroundColor: t.bg }}>
      {scroll
        ? <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={[{ padding: 16, paddingBottom: 40 }, style]}>{children}</ScrollView>
        : <View style={[{ flex: 1, padding: 16 }, style]}>{children}</View>}
    </SafeAreaView>
  );
}
