export type MealId = 'b' | 'l' | 'd' | 's';
export const MEALS: { id: MealId; name: string; em: string; words: string[] }[] = [
  { id: 'b', name: 'Завтрак', em: '🍳', words: ['завтрак', 'утром'] },
  { id: 'l', name: 'Обед', em: '🍲', words: ['обед', 'днём', 'днем'] },
  { id: 'd', name: 'Ужин', em: '🥗', words: ['ужин', 'вечером'] },
  { id: 's', name: 'Перекусы', em: '🍎', words: ['перекус', 'снек'] },
];

/** Значения КБЖУ — на 100 г */
export interface Food {
  id: string;
  name: string;
  brand?: string | null;
  barcode?: string | null;
  kcal: number; protein: number; fat: number; carbs: number;
  portionG: number;
  unit: string;
  source: 'seed' | 'off' | 'user';
  /** 0..1: 1 = проверено/сходится по формуле Этуотера */
  quality: number;
  aliases?: string[];
}

export interface Entry {
  id: string; date: string; meal: MealId; name: string; grams: number;
  kcal: number; protein: number; fat: number; carbs: number;
  foodId?: string; updatedAt: number; deleted?: boolean;
}

export interface Profile {
  name: string; sex: 'm' | 'f'; age: number; height: number; weight: number; goalWeight: number;
  activity: number; goal: 'lose' | 'keep' | 'gain'; updatedAt: number;
}

export interface Settings {
  theme: 'system' | 'light' | 'dark';
  social: boolean;
  serverUrl: string;
  eatBack: 0 | 50 | 100;       // какую долю активных ккал из Samsung Health прибавлять к норме
  hcEnabled: boolean;
  hcWriteWeight: boolean;
  hcWriteNutrition: boolean;
  llmPreset?: string;
  llmUrl?: string;
  llmKey?: string;
  llmModel?: string;
  /** Как считать норму: auto — лучший доступный способ */
  normMode?: 'auto' | 'mifflin' | 'katch' | 'adaptive';
  /** Пользователь согласился отправлять фото документов в AI-модель */
  visionConsent?: boolean;
}

/** Обхваты тела, см. Ключ в сторе — дата. */
export interface Measure { waist?: number; hips?: number; chest?: number; neck?: number; biceps?: number; thigh?: number; calf?: number; updatedAt: number }

/** Состав тела (БИА, умные весы, часы). Всё необязательное: что смогли считать, то и записано. */
export interface BodyComp {
  id: string; date: string;
  source: 'manual' | 'photo' | 'health';
  weightKg?: number; fatPct?: number; muscleKg?: number; leanKg?: number; waterPct?: number; visceral?: number; boneKg?: number; bmr?: number;
  updatedAt: number;
}

/** Показатель анализа (кровь и т.п.). Хранится только на телефоне. */
export interface LabItem { id: string; date: string; name: string; value: number; unit: string; refLow?: number | null; refHigh?: number | null; updatedAt: number }
