import type { Entry, Food, Profile } from './types';

export const r0 = (n: number) => Math.round(n);
export const r1 = (n: number) => Math.round(n * 10) / 10;
export const fmt = (n: number) => Math.round(n).toLocaleString('ru-RU');
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

export const dkey = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export const today = () => dkey(new Date());
export const parseKey = (k: string) => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
export const addDays = (k: string, n: number) => { const d = parseKey(k); d.setDate(d.getDate() + n); return dkey(d); };

export function macroFor(f: Pick<Food, 'kcal' | 'protein' | 'fat' | 'carbs'>, grams: number) {
  return { kcal: r0((f.kcal * grams) / 100), protein: r1((f.protein * grams) / 100), fat: r1((f.fat * grams) / 100), carbs: r1((f.carbs * grams) / 100) };
}

export interface Targets { kcal: number; protein: number; fat: number; carbs: number; tdee: number; waterMl: number; limited?: boolean; minor?: boolean }
/** Расход (по формуле Миффлина–Сан Жеора или переданный готовый) → поправка на цель. Ниже безопасного минимума не опускаем. */
export function targets(p: Profile, tdeeOverride?: number): Targets {
  const bmr = 10 * p.weight + 6.25 * p.height - 5 * p.age + (p.sex === 'm' ? 5 : -161);
  const tdee = tdeeOverride ?? bmr * p.activity;
  const minor = p.age < 18;
  const goal = minor && p.goal === 'lose' ? 'keep' : p.goal;
  const raw = Math.round((goal === 'lose' ? tdee * 0.85 : goal === 'gain' ? tdee * 1.1 : tdee) / 10) * 10;
  const floor = p.sex === 'm' ? 1500 : 1200;
  const limited = goal === 'lose' && raw < floor;
  const kcal = limited ? floor : raw;
  const protein = r0(p.weight * (goal === 'lose' ? 1.9 : goal === 'gain' ? 1.8 : 1.5));
  const fat = r0((kcal * 0.27) / 9);
  const carbs = Math.max(50, r0((kcal - protein * 4 - fat * 9) / 4));
  return { kcal, protein, fat, carbs, tdee: r0(tdee), waterMl: Math.round((p.weight * 33) / 250) * 250, limited, minor };
}

export function sum(entries: Entry[]) {
  return entries.reduce((a, e) => ({ kcal: a.kcal + e.kcal, protein: a.protein + e.protein, fat: a.fat + e.fat, carbs: a.carbs + e.carbs }), { kcal: 0, protein: 0, fat: 0, carbs: 0 });
}

export function dateLabel(k: string) {
  if (k === today()) return 'Сегодня';
  if (k === addDays(today(), -1)) return 'Вчера';
  if (k === addDays(today(), 1)) return 'Завтра';
  return parseKey(k).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', weekday: 'short' });
}

export function guessMeal(text = '', now = new Date()): 'b' | 'l' | 'd' | 's' {
  const t = text.toLowerCase();
  if (/завтрак|утром/.test(t)) return 'b';
  if (/обед|днем|днём/.test(t)) return 'l';
  if (/ужин|вечером/.test(t)) return 'd';
  if (/перекус|снек/.test(t)) return 's';
  const h = now.getHours();
  return h < 11 ? 'b' : h < 16 ? 'l' : h < 21 ? 'd' : 's';
}
