import type { Entry, Profile } from './types';
import { addDays, fmt, macroFor, r0, sum, targets, today, type Targets } from './nutrition';
import { SEED_FOODS } from './foods';

export interface CoachCtx { profile: Profile; entries: Entry[]; waterMl: number; allEntries: Record<string, Entry>; activeKcal?: number; T?: Targets }

const suggest = (left: number, snack = false) => {
  const pool = SEED_FOODS.filter(f => (snack ? ['yog', 'cott0', 'app', 'ban', 'alm', 'bar', 'egg', 'kef', 'tuna'].some(id => f.id === 'seed:' + id) : f.protein >= 12 && f.kcal < 300 && !/Пиво|Вино/.test(f.name)))
    .sort((a, b) => b.protein / b.kcal - a.protein / a.kcal);
  const res: { name: string; port: number; kcal: number; p: number }[] = [];
  let k = left;
  for (const f of pool) { const m = macroFor(f, f.portionG); if (m.kcal <= Math.max(k, 0) + 50 || res.length < 1) { res.push({ name: f.name, port: f.portionG, kcal: m.kcal, p: m.protein }); k -= m.kcal; } if (res.length >= 3) break; }
  return res;
};

export function localAnswer(q: string, c: CoachCtx): string {
  const T = c.T ?? targets(c.profile), t = sum(c.entries), left = T.kcal - t.kcal, ql = q.toLowerCase(), p = c.profile;
  if (/разбор дня|разбор моего дня|итог|как я сегодня/.test(ql)) {
    if (!c.entries.length) return 'Сегодня ещё ничего не записано. Напишите, что ели на завтрак, — я всё посчитаю 🌱';
    let s = `📊 Разбор дня\n\nКалории: ${fmt(t.kcal)} из ${fmt(T.kcal)} (${r0((t.kcal / T.kcal) * 100)}%).\nБелки ${r0(t.protein)}/${T.protein} г · Жиры ${r0(t.fat)}/${T.fat} г · Углеводы ${r0(t.carbs)}/${T.carbs} г.\n\n`;
    s += t.protein / T.protein < 0.7 ? '• Белка маловато — добавьте творог, рыбу или курицу.\n' : '• Белок в хорошей форме 👍\n';
    if (t.fat / T.fat > 1.1) s += '• Жиров многовато — меньше соусов и жареного.\n';
    if (t.carbs / T.carbs > 1.15) s += '• Углеводов выше нормы — обратите внимание на сладкое.\n';
    s += c.waterMl < T.waterMl * 0.6 ? `• Воды ${c.waterMl} из ${T.waterMl} мл — пейте чаще.\n` : '• С водой всё хорошо 💧\n';
    return s + (left > 0 ? `\nОсталось ${fmt(left)} ккал.` : `\nПревышение ${fmt(-left)} ккал — завтра можно слегка уменьшить порции.`);
  }
  if (/недел/.test(ql)) {
    const days = Array.from({ length: 7 }, (_, i) => addDays(today(), i - 6));
    const v = days.map(d => sum(Object.values(c.allEntries).filter(e => e.date === d)).kcal).filter(x => x > 0);
    if (!v.length) return 'Пока мало данных для разбора недели.';
    const avg = r0(v.reduce((a, b) => a + b, 0) / v.length);
    return `📈 Ваша неделя\n\nВ среднем ${fmt(avg)} ккал/день при цели ${fmt(T.kcal)}. Дней с записями: ${v.length} из 7.\n\n1. ${v.length < 7 ? 'Ведите дневник каждый день — даже «неидеальные» дни важны.' : 'Отличная регулярность!'}\n2. ${avg > T.kcal ? 'Среднее выше цели — уменьшите вечерние порции.' : 'Калораж под контролем.'}\n3. Держите белок около ${T.protein} г.`;
  }
  if (/остал/.test(ql)) return left > 0 ? `Осталось ${fmt(left)} ккал, белка — ещё ${Math.max(0, r0(T.protein - t.protein))} г, жиров — ${Math.max(0, r0(T.fat - t.fat))} г, углеводов — ${Math.max(0, r0(T.carbs - t.carbs))} г.` : `Норма выполнена; перебор ${fmt(-left)} ккал. Прогулка и вода не помешают 🚶`;
  if (/перебор|превыс|сорвал|срыв/.test(ql)) return 'Спокойно — один день не определяет результат 🙂\n\n1. Не «отрабатывайте» голодом: завтра ешьте как обычно.\n2. Больше белка и овощей — они насыщают.\n3. Вода и прогулка 20–30 минут.\n4. Главное — продолжать вести дневник.';
  if (/ужин|добрать белок|белок/.test(ql)) { const s = suggest(left); return `Нужно добрать около ${Math.max(0, r0(T.protein - t.protein))} г белка при остатке ${fmt(Math.max(left, 0))} ккал. Варианты:\n\n` + s.map(x => `• ${x.name}, ${x.port} г — ${x.kcal} ккал, белка ${r0(x.p)} г`).join('\n'); }
  if (/перекус|снек|голод/.test(ql)) return 'Лёгкие перекусы:\n\n' + suggest(left, true).map(x => `• ${x.name}, ${x.port} г — ${x.kcal} ккал (белка ${r0(x.p)} г)`).join('\n');
  if (/завтрак/.test(ql)) return 'Сытный завтрак на ~400 ккал:\n\n• Омлет из 2 яиц — 250 ккал, 14 г белка\n• Ломтик ржаного хлеба и помидор — 80 ккал\n• Кофе с молоком — 50 ккал 🍳';
  if (/вод|пить/.test(ql)) return `Ориентир — около ${T.waterMl} мл в день (≈${p.weight} кг × 33 мл). Сегодня выпито ${c.waterMl} мл 💧`;
  if (/вес|похуд|цель|быстрее/.test(ql)) { const diff = p.weight - p.goalWeight, weeks = diff > 0 ? Math.ceil(diff / 0.5) : 0; return `Сейчас ${p.weight} кг, цель ${p.goalWeight} кг. Безопасный темп — 0,3–0,7 кг в неделю, то есть примерно ${weeks || '—'} нед. Дефицит уже заложен в норму (${fmt(T.kcal)} ккал вместо ${fmt(T.tdee)} ккал расхода).`; }
  return `Вижу ваши данные за сегодня: ${fmt(t.kcal)} из ${fmt(T.kcal)} ккал. Спросите: «что съесть на ужин», «сколько осталось» или «разбор дня».\n\nДля свободного диалога подключите сервер с LLM (Профиль → Аккаунт).`;
}

export const contextString = (c: CoachCtx) => {
  const T = c.T ?? targets(c.profile), t = sum(c.entries);
  return `Профиль: ${c.profile.sex === 'm' ? 'муж' : 'жен'}, ${c.profile.age} лет, ${c.profile.height} см, ${c.profile.weight} кг, цель ${c.profile.goalWeight} кг (${c.profile.goal}). Норма: ${T.kcal} ккал, Б${T.protein} Ж${T.fat} У${T.carbs}. Сегодня: ${t.kcal} ккал, Б${r0(t.protein)} Ж${r0(t.fat)} У${r0(t.carbs)}, вода ${c.waterMl} мл${c.activeKcal ? ', активность ' + c.activeKcal + ' ккал' : ''}. Блюда: ${c.entries.map(e => e.name + ' ' + e.grams + 'г').join('; ') || 'ничего'}.`;
};
