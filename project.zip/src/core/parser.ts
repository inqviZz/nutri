import type { Food } from './types';
import { macroFor, r0 } from './nutrition';

/** Насколько можно доверять количеству: названо граммами / по стандартной порции / просто угадано */
export type Precision = 'exact' | 'standard' | 'guess';
export interface ParsedRow { food: Food | null; label: string; grams: number; precision: Precision }

const NUMW: Record<string, number> = { один: 1, одна: 1, одно: 1, одну: 1, два: 2, две: 2, три: 3, четыре: 4, пять: 5, шесть: 6, семь: 7, восемь: 8, десять: 10, пол: 0.5, половин: 0.5, полтор: 1.5 };
const norm = (s: string) => s.toLowerCase().replace(/ё/g, 'е');

const stemsOf = (f: Food) => (f.aliases?.length ? f.aliases : [f.name]).map(norm);

/** Находит продукт по названию: побеждает самая длинная подходящая основа слова. */
export function matchFood(text: string, foods: Food[]): Food | null {
  const t = norm(text);
  let best: Food | null = null, bl = 0;
  for (const f of foods) for (const s of stemsOf(f)) if (s.length > 2 && t.includes(s) && s.length > bl) { best = f; bl = s.length; }
  if (best) return best;
  // запасной вариант: название продукта целиком содержит слово из запроса (напр. «гречка отварная» ↔ «гречка»)
  const words = t.split(/[^\p{L}\p{N}]+/u).filter(w => w.length > 3);
  for (const f of foods) { const n = norm(f.name); if (words.length && words.every(w => n.includes(w.slice(0, Math.max(4, w.length - 2))))) return f; }
  return null;
}

export function parseText(text: string, foods: Food[]): ParsedRow[] {
  let prot = norm(text);
  // «кофе с молоком», «чай с сахаром» — не резать по « с »
  for (const f of foods) for (const s of stemsOf(f)) if (s.includes(' с ')) prot = prot.split(s).join(s.replace(/ /g, '_'));
  const chunks = prot.split(/[,;.\n]| и | плюс | \+ | потом | еще | а также | с |\sсо /).map(s => s.trim().replace(/_/g, ' ')).filter(Boolean);
  const out: ParsedRow[] = [];
  for (const ch of chunks) {
    const food = matchFood(ch, foods);
    if (!food) continue;
    let grams = food.portionG, precision: Precision = 'guess';
    const gm = ch.match(/(\d+[.,]?\d*)\s*(кг|г|гр|грамм\S*|мл|ml|g)(?![а-яa-z])/);
    if (gm) { grams = Number(gm[1].replace(',', '.')); if (gm[2] === 'кг') grams *= 1000; precision = 'exact'; }
    else {
      let mult: number | null = null;
      const nm = ch.match(/(\d+[.,]?\d*)/);
      if (nm) mult = Number(nm[1].replace(',', '.'));
      else for (const w of Object.keys(NUMW)) if (new RegExp('(^|\\s)' + w).test(ch)) { mult = NUMW[w]; break; }
      if (mult !== null) { grams = food.portionG * mult; precision = 'standard'; }
    }
    grams = r0(grams);
    if (grams > 0 && grams < 5000) out.push({ food, label: food.name, grams, precision });
  }
  return out;
}

export const rowMacro = (r: ParsedRow) => (r.food ? macroFor(r.food, r.grams) : { kcal: 0, protein: 0, fat: 0, carbs: 0 });
