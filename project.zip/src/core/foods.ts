import seed from '../data/foods.seed.json';
import type { Food } from './types';

export const SEED_FOODS: Food[] = (seed as any[]).map(f => ({
  id: 'seed:' + f.id, name: f.name, brand: null, barcode: null, kcal: f.kcal, protein: f.protein, fat: f.fat, carbs: f.carbs,
  portionG: f.portionG, unit: f.unit, source: 'seed', quality: 1, aliases: f.aliases,
}));

const norm = (s: string) => s.toLowerCase().replace(/ё/g, 'е');
/** Быстрый локальный поиск (офлайн): по названию, бренду и основам слов. */
export function searchFoodsLocal(q: string, foods: Food[], limit = 30): Food[] {
  const words = norm(q).split(/[^\p{L}\p{N}]+/u).filter(Boolean);
  if (!words.length) return [];
  const score = (f: Food) => {
    const hay = norm(f.name + ' ' + (f.brand ?? '') + ' ' + (f.aliases ?? []).join(' '));
    let s = 0;
    for (const w of words) {
      const stem = w.length > 4 ? w.slice(0, w.length - 2) : w;
      if (hay.includes(w)) s += 2; else if (hay.includes(stem)) s += 1; else return -1;
    }
    return s + (f.source === 'seed' ? 0.5 : 0) + f.quality * 0.1;
  };
  return foods.map(f => ({ f, s: score(f) })).filter(x => x.s >= 0).sort((a, b) => b.s - a.s).slice(0, limit).map(x => x.f);
}
