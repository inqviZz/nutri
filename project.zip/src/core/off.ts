import type { Food } from './types';

/** Копия проверок из backend/src/off.ts: клиент может ходить в Open Food Facts и без сервера. */
const num = (v: unknown): number | null => {
  const n = typeof v === 'string' ? parseFloat(v.replace(',', '.')) : (v as number);
  return typeof n === 'number' && Number.isFinite(n) ? n : null;
};

export function normalizeOff(p: any): Food | null {
  const n = p?.nutriments ?? {};
  const name = String(p?.product_name_ru || p?.product_name || '').trim();
  if (!p?.code || !name) return null;
  let kcal = num(n['energy-kcal_100g']);
  if (kcal === null) { const kj = num(n['energy-kj_100g']) ?? num(n['energy_100g']); if (kj !== null) kcal = kj / 4.184; }
  const protein = num(n['proteins_100g']), fat = num(n['fat_100g']), carbs = num(n['carbohydrates_100g']);
  if (kcal === null || protein === null || fat === null || carbs === null) return null;
  if (kcal < 0 || kcal > 900 || protein < 0 || fat < 0 || carbs < 0 || protein + fat + carbs > 105) return null;
  const rel = Math.abs(4 * protein + 9 * fat + 4 * carbs - kcal) / Math.max(kcal, 50);
  const quality = rel <= 0.15 ? 1 : rel <= 0.3 ? 0.7 : rel <= 0.5 ? 0.4 : 0.1;
  if (quality < 0.4) return null;
  const serv = num(p.serving_quantity);
  return {
    id: 'off:' + p.code, source: 'off', barcode: String(p.code), name, brand: String(p.brands || '').split(',')[0].trim() || null,
    kcal: Math.round(kcal), protein: +protein.toFixed(1), fat: +fat.toFixed(1), carbs: +carbs.toFixed(1),
    portionG: serv && serv > 0 && serv < 2000 ? serv : 100, unit: serv ? 'порция' : '100 г', quality,
  };
}

const FIELDS = 'code,product_name,product_name_ru,brands,nutriments,serving_quantity';
export async function offBarcode(code: string): Promise<Food | null> {
  const r = await fetch(`https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(code)}.json?fields=${FIELDS}`);
  if (!r.ok) return null;
  const j = await r.json();
  return j.status === 1 ? normalizeOff({ ...j.product, code }) : null;
}
