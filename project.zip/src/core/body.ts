import type { BodyComp, Entry, LabItem, Measure, Profile } from './types';
import { addDays, parseKey, r0, r1, targets, today, type Targets } from './nutrition';

export const MEASURE_FIELDS: [keyof Omit<Measure, 'updatedAt'>, string][] = [
  ['waist', 'Талия'], ['hips', 'Бёдра'], ['chest', 'Грудь'], ['neck', 'Шея'], ['biceps', 'Рука (бицепс)'], ['thigh', 'Бедро'], ['calf', 'Голень'],
];

/** Отношение талии к росту. До 0,5 — хорошо; 0,5–0,6 — повышено; выше — высокий риск. */
export const whtr = (waist: number, height: number) => (waist > 0 && height > 0 ? waist / height : null);
export function whtrLabel(v: number) { return v < 0.43 ? 'очень низкое' : v < 0.5 ? 'в норме' : v < 0.6 ? 'повышено' : 'высокое'; }

/** Оценка % жира по методу ВМС США (обхваты, см). Точность грубая, ±3–5 п.п. */
export function navyFat(sex: 'm' | 'f', height: number, waist: number, neck: number, hips?: number): number | null {
  if (!(height > 100 && waist > 0 && neck > 0)) return null;
  let v: number;
  if (sex === 'm') { if (waist <= neck) return null; v = 495 / (1.0324 - 0.19077 * Math.log10(waist - neck) + 0.15456 * Math.log10(height)) - 450; }
  else { if (!hips || waist + hips <= neck) return null; v = 495 / (1.29579 - 0.35004 * Math.log10(waist + hips - neck) + 0.221 * Math.log10(height)) - 450; }
  return v > 3 && v < 60 ? r1(v) : null;
}

export const leanFrom = (weight: number, fatPct: number) => weight * (1 - fatPct / 100);
/** Кэтч–Макардл: основной обмен по безжировой массе */
export const katchBmr = (leanKg: number) => 370 + 21.6 * leanKg;
export const bmi = (kg: number, cm: number) => (cm > 0 ? kg / ((cm / 100) ** 2) : 0);

/** Наклон прямой (МНК): y по x */
export function slope(pts: { x: number; y: number }[]) {
  const n = pts.length; if (n < 2) return 0;
  const mx = pts.reduce((a, p) => a + p.x, 0) / n, my = pts.reduce((a, p) => a + p.y, 0) / n;
  let num = 0, den = 0; for (const p of pts) { num += (p.x - mx) * (p.y - my); den += (p.x - mx) ** 2; }
  return den ? num / den : 0;
}

export interface Adaptive { tdee: number; avgIntake: number; kgPerWeek: number; loggedDays: number; weighIns: number; spanDays: number; confidence: 'low' | 'medium' | 'high' }
/**
 * «Реальный» расход по вашим данным за 28 дней: средняя еда в дни с записями минус энергия, ушедшая в изменение веса (≈7700 ккал на кг).
 * Работает, если вы ведёте дневник почти полностью и взвешиваетесь регулярно.
 */
export function adaptiveTdee(entries: Record<string, Entry>, weights: Record<string, { kg: number }>, now = today()): Adaptive | null {
  const from = addDays(now, -27);
  const perDay: Record<string, number> = {};
  for (const e of Object.values(entries)) if (e.date >= from && e.date <= now) perDay[e.date] = (perDay[e.date] ?? 0) + e.kcal;
  const logged = Object.entries(perDay).filter(([d, k]) => k >= 800 && d < now).map(([, k]) => k);
  const ws = Object.entries(weights).filter(([d]) => d >= from && d <= now).sort((a, b) => (a[0] < b[0] ? -1 : 1));
  if (logged.length < 10 || ws.length < 4) return null;
  const t0 = parseKey(ws[0][0]).getTime();
  const pts = ws.map(([d, w]) => ({ x: (parseKey(d).getTime() - t0) / 864e5, y: w.kg }));
  const span = pts[pts.length - 1].x; if (span < 10) return null;
  const perDayKg = slope(pts);
  const avg = logged.reduce((a, b) => a + b, 0) / logged.length;
  const tdee = avg - perDayKg * 7700;
  if (!(tdee > 1000 && tdee < 5000)) return null;
  const confidence = logged.length >= 21 && ws.length >= 8 && span >= 18 ? 'high' : logged.length >= 14 && ws.length >= 5 && span >= 12 ? 'medium' : 'low';
  return { tdee: r0(tdee), avgIntake: r0(avg), kgPerWeek: r1(perDayKg * 7), loggedDays: logged.length, weighIns: ws.length, spanDays: r0(span), confidence };
}

export interface Basis {
  mode: 'mifflin' | 'katch' | 'adaptive';
  tdee: number;
  methods: { mifflin: number; katch?: number; adaptive?: Adaptive };
  fatPct?: number; fatDate?: string; leanKg?: number;
  why: string;
}

const mifflinBmr = (p: Profile) => 10 * p.weight + 6.25 * p.height - 5 * p.age + (p.sex === 'm' ? 5 : -161);

/** Выбирает способ расчёта расхода и объясняет выбор простыми словами. */
export function basisFor(p: Profile, entries: Record<string, Entry>, weights: Record<string, { kg: number }>, comps: Record<string, BodyComp>, pref: 'auto' | 'mifflin' | 'katch' | 'adaptive' = 'auto', now = today()): Basis {
  const mif = Math.round(mifflinBmr(p) * p.activity);
  const since = addDays(now, -90);
  const bia = Object.values(comps).filter(c => c.fatPct && c.date >= since && c.date <= now).sort((a, b) => (a.date < b.date ? 1 : -1))[0];
  const lean = bia?.fatPct ? leanFrom(p.weight, bia.fatPct) : undefined;
  const kat = lean ? Math.round(katchBmr(lean) * p.activity) : undefined;
  const ad = adaptiveTdee(entries, weights, now) ?? undefined;
  const base = { methods: { mifflin: mif, katch: kat, adaptive: ad }, fatPct: bia?.fatPct, fatDate: bia?.date, leanKg: lean && r1(lean) };
  const pickAdaptive = ad && (pref === 'adaptive' || (pref === 'auto' && ad.confidence !== 'low'));
  if (pickAdaptive) return { ...base, mode: 'adaptive', tdee: ad.tdee, why: `По вашим данным за ${ad.spanDays} дн.: вы съедали в среднем ${ad.avgIntake} ккал, вес менялся на ${ad.kgPerWeek > 0 ? '+' : ''}${ad.kgPerWeek} кг в неделю.` };
  if (kat && (pref === 'katch' || pref === 'auto')) return { ...base, mode: 'katch', tdee: kat, why: `По составу тела: ${bia!.fatPct}% жира (${bia!.date}) → безжировая масса ≈ ${r1(lean!)} кг.` };
  return { ...base, mode: 'mifflin', tdee: mif, why: pref === 'adaptive' || pref === 'katch' ? 'Для выбранного способа пока не хватает данных, использована общая формула (возраст, рост, вес).' : 'Общая формула по возрасту, росту и весу. Точнее станет, когда появятся данные о составе тела или 2–4 недели дневника с весом.' };
}

export type FullTargets = Targets & { basis: Basis };
export function fullTargets(p: Profile, entries: Record<string, Entry>, weights: Record<string, { kg: number }>, comps: Record<string, BodyComp>, pref?: 'auto' | 'mifflin' | 'katch' | 'adaptive'): FullTargets {
  const basis = basisFor(p, entries, weights, comps, pref);
  return { ...targets(p, basis.tdee), basis };
}

/** Попадает ли значение анализа в референс, указанный в бланке. */
export function labFlag(l: Pick<LabItem, 'value' | 'refLow' | 'refHigh'>): 'low' | 'high' | 'ok' | 'none' {
  if (l.refLow == null && l.refHigh == null) return 'none';
  if (l.refLow != null && l.value < l.refLow) return 'low';
  if (l.refHigh != null && l.value > l.refHigh) return 'high';
  return 'ok';
}

/** Проверка правдоподобности распознанного состава тела: отбрасывает невозможные значения. */
export function sanitizeComp(c: Partial<BodyComp>): Partial<BodyComp> {
  const out: Partial<BodyComp> = {};
  const rng = (k: keyof BodyComp, v: any, lo: number, hi: number) => { const n = Number(v); if (Number.isFinite(n) && n >= lo && n <= hi) (out as any)[k] = Math.round(n * 10) / 10; };
  rng('weightKg', c.weightKg, 25, 300); rng('fatPct', c.fatPct, 2, 65); rng('muscleKg', c.muscleKg, 10, 150); rng('leanKg', c.leanKg, 20, 200);
  rng('waterPct', c.waterPct, 25, 80); rng('visceral', c.visceral, 1, 60); rng('boneKg', c.boneKg, 0.5, 8); rng('bmr', c.bmr, 700, 4000);
  return out;
}
