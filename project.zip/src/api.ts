import type { Food } from './core/types';
import { offBarcode } from './core/off';
import { useStore, type Change } from './store';
import { callLlm, COACH_SYSTEM, llmConfigured, llmParse } from './llm';
import { logEvent } from './diag';

export const DEFAULT_SERVER = '';  // например 'http://192.168.1.10:8787' или 'https://api.your-domain.app'

function base() { return (useStore.getState().settings.serverUrl || DEFAULT_SERVER).replace(/\/$/, ''); }
export const serverConfigured = () => !!base();

async function req(path: string, init: RequestInit = {}, auth = true): Promise<any> {
  const b = base(); if (!b) throw new Error('no_server');
  const token = useStore.getState().token;
  const r = await fetch(b + path, {
    ...init, headers: { 'Content-Type': 'application/json', ...(auth && token ? { Authorization: 'Bearer ' + token } : {}), ...(init.headers || {}) },
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(j.error || 'http_' + r.status), { status: r.status });
  return j;
}

export async function login(mode: 'login' | 'register', email: string, password: string) {
  const j = await req('/auth/' + mode, { method: 'POST', body: JSON.stringify({ email, password }) }, false);
  useStore.getState().setAuth(j.token, email);
}

export async function searchRemote(q: string): Promise<Food[]> {
  if (!serverConfigured()) return [];
  const j = await req('/foods/search?q=' + encodeURIComponent(q), {}, false);
  return j.foods as Food[];
}

/** Штрихкод: кэш → свой сервер → Open Food Facts напрямую. */
export async function lookupBarcode(code: string): Promise<Food | null> {
  const st = useStore.getState();
  const cached = Object.values({ ...st.foodCache, ...st.customFoods }).find(f => f.barcode === code);
  if (cached) return cached;
  let food: Food | null = null;
  if (serverConfigured()) { try { food = (await req('/foods/barcode/' + code, {}, false)).food; } catch (e: any) { if (e.status !== 404) { food = null; logEvent('barcode-server', e); } } }
  if (!food) { try { food = await offBarcode(code); } catch (e) { food = null; logEvent('barcode-off', e); } }
  if (food) st.cacheFoods([food]);
  return food;
}

export async function aiParse(text: string): Promise<{ name: string; grams: number; assumed: boolean; confidence: number; meal?: string }[] | null> {
  if (llmConfigured()) { try { return await llmParse(text); } catch (e) { logEvent('ai-parse', e); return null; } }
  if (!serverConfigured() || !useStore.getState().token) return null;
  try { return (await req('/ai/parse', { method: 'POST', body: JSON.stringify({ text }) })).items; } catch { return null; }
}

export async function aiChat(messages: { role: string; content: string }[], context: string): Promise<string | null> {
  if (llmConfigured()) {
    try { return await callLlm([{ role: 'system', content: COACH_SYSTEM + '\n\nДанные пользователя: ' + context }, ...messages.slice(-10)], 0.5); }
    catch (e: any) { logEvent('ai-chat', e); return null; }
  }
  if (!serverConfigured() || !useStore.getState().token) return null;
  try { return (await req('/ai/chat', { method: 'POST', body: JSON.stringify({ messages, context }) })).reply; } catch { return null; }
}

export async function publishFood(f: Food) {
  if (!serverConfigured() || !useStore.getState().token || !f.barcode) return;
  try { await req('/foods', { method: 'POST', body: JSON.stringify({ barcode: f.barcode, name: f.name, brand: f.brand ?? undefined, kcal: f.kcal, protein: f.protein, fat: f.fat, carbs: f.carbs, portionG: f.portionG }) }); } catch {}
}

/** Двусторонняя синхронизация: отправляем outbox, забираем чужие изменения (last-write-wins). */
export async function syncNow(): Promise<{ pushed: number; pulled: number }> {
  const st = useStore.getState();
  if (!st.token) throw new Error('not_logged_in');
  let pushed = 0, pulled = 0, cursor = st.cursor;
  for (let i = 0; i < 10; i++) {
    const changes = Object.values(useStore.getState().outbox).slice(0, 500) as Change[];
    const j = await req('/sync', { method: 'POST', body: JSON.stringify({ cursor, changes }) });
    useStore.getState().clearOutbox(changes.map(c => c.id));
    pushed += j.accepted; pulled += j.changes.length; cursor = j.cursor;
    useStore.getState().applyRemote(j.changes, cursor);
    if (!j.more && Object.keys(useStore.getState().outbox).length === 0) break;
  }
  return { pushed, pulled };
}
