import AsyncStorage from '@react-native-async-storage/async-storage';

/** Журнал последних событий/ошибок. Хранится на телефоне и попадает в отчёт для разработчика. */
export interface LogItem { t: number; kind: string; msg: string }
let items: LogItem[] = [];
let loaded = false;
const KEY = 'nutri-log-v1';

export async function loadLog() {
  if (loaded) return; loaded = true;
  try { const raw = await AsyncStorage.getItem(KEY); if (raw) items = [...JSON.parse(raw), ...items].slice(-80); } catch {}
}
export function logEvent(kind: string, e: unknown) {
  const msg = String((e as any)?.message ?? e).slice(0, 300);
  items.push({ t: Date.now(), kind, msg }); items = items.slice(-80);
  AsyncStorage.setItem(KEY, JSON.stringify(items)).catch(() => {});
}
export const getLog = () => items;
export function clearLog() { items = []; AsyncStorage.removeItem(KEY).catch(() => {}); }

/** Ловит необработанные ошибки (падения) в журнал, не ломая стандартное поведение. */
export function installCrashLogger() {
  const EU = (globalThis as any).ErrorUtils;
  if (!EU?.setGlobalHandler || (installCrashLogger as any).done) return;
  (installCrashLogger as any).done = true;
  const prev = EU.getGlobalHandler?.();
  EU.setGlobalHandler((err: any, fatal?: boolean) => { logEvent(fatal ? 'CRASH' : 'js-error', err); prev?.(err, fatal); });
}
