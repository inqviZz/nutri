import { useEffect } from 'react';
import { AppState } from 'react-native';
import { addDays, today } from './core/nutrition';
import { readActivity, readBodyComp, readWeights } from './health';
import { useStore } from './store';
import { logEvent } from './diag';

/** Подтягивает активность и вес из Samsung Health (через Health Connect) за последние дни. */
export async function refreshHealth(days = 7) {
  const st = useStore.getState();
  if (!st.settings.hcEnabled) return;
  try {
    const keys = Array.from({ length: days }, (_, i) => addDays(today(), -i));
    st.setHealth(await readActivity(keys));
    for (const w of await readWeights(60)) {
      const cur = useStore.getState().weights[w.date];
      if (!cur || (cur.source === 'health' && cur.kg !== w.kg)) useStore.getState().setWeight(w.date, w.kg, 'health');
    }
    // состав тела (если часы/весы/Samsung Health его передают)
    const have = new Set(Object.values(useStore.getState().bodycomp).filter(c => c.source === 'health').map(c => c.id));
    for (const c of await readBodyComp(90)) {
      if (!c.fatPct && !c.leanKg && !c.bmr) continue;
      const id = 'hc-' + c.date;
      const w = useStore.getState().weights[c.date]?.kg;
      const cur = useStore.getState().bodycomp[id];
      if (!have.has(id) || cur?.fatPct !== c.fatPct || cur?.leanKg !== c.leanKg || cur?.bmr !== c.bmr) useStore.getState().addBodyComp({ id, date: c.date, source: 'health', fatPct: c.fatPct, leanKg: c.leanKg, bmr: c.bmr, weightKg: w });
    }
  } catch (e) { logEvent('hc-refresh', e); }
}

export function useHealthAutoRefresh() {
  const enabled = useStore(s => s.settings.hcEnabled);
  useEffect(() => {
    if (!enabled) return;
    refreshHealth();
    const sub = AppState.addEventListener('change', st => { if (st === 'active') refreshHealth(); });
    return () => sub.remove();
  }, [enabled]);
}
